/**
 * Backend API Endpoints for Cross-Device Authentication
 *
 * This file contains example API endpoints that work with the frontend auth system.
 * Deploy these endpoints to enable true cross-device login.
 *
 * Framework: Express.js (can be adapted to Next.js API routes, Fastify, etc.)
 */

import express from "express"
import bcrypt from "bcrypt"
import jwt from "jsonwebtoken"
import { db } from "./database" // Your database connection

const router = express.Router()

// Environment variables
const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key"
const JWT_EXPIRES_IN = process.env.JWT_EXPIRES_IN || "30d"

/**
 * POST /api/register
 * Register a new user account
 *
 * Request body:
 * {
 *   "username": "john_doe",
 *   "email": "john@example.com",
 *   "password": "securepassword123",
 *   "name": "John Doe",
 *   "profilePhoto": "base64_image_data"
 * }
 *
 * Response:
 * {
 *   "success": true,
 *   "user": {
 *     "id": "uuid",
 *     "username": "john_doe",
 *     "email": "john@example.com",
 *     "name": "John Doe",
 *     "profilePhoto": "base64_data",
 *     "token": "jwt_token"
 *   }
 * }
 */
router.post("/api/register", async (req, res) => {
  try {
    const { username, email, password, name, profilePhoto } = req.body

    // Validate input
    if (!username || !email || !password) {
      return res.status(400).json({
        success: false,
        error: "Username, email, and password are required",
      })
    }

    // Validate username format (3-20 chars, alphanumeric + underscore)
    if (!/^[a-zA-Z0-9_]{3,20}$/.test(username)) {
      return res.status(400).json({
        success: false,
        error: "Username must be 3-20 characters (letters, numbers, underscore only)",
      })
    }

    // Validate email format
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
      return res.status(400).json({
        success: false,
        error: "Invalid email format",
      })
    }

    // Validate password length
    if (password.length < 8) {
      return res.status(400).json({
        success: false,
        error: "Password must be at least 8 characters",
      })
    }

    // Check if username or email already exists
    const existingUser = await db.query("SELECT id FROM users WHERE username = $1 OR email = $2", [username, email])

    if (existingUser.rows.length > 0) {
      return res.status(409).json({
        success: false,
        error: "Username or email already registered",
      })
    }

    // Hash password with bcrypt (much more secure than SHA-256)
    const passwordHash = await bcrypt.hash(password, 10)

    // Insert new user into database
    const result = await db.query(
      `INSERT INTO users (username, email, password_hash, name, profile_photo)
       VALUES ($1, $2, $3, $4, $5)
       RETURNING id, username, email, name, profile_photo, created_at`,
      [username, email, passwordHash, name, profilePhoto],
    )

    const newUser = result.rows[0]

    // Generate JWT token
    const token = jwt.sign(
      {
        userId: newUser.id,
        username: newUser.username,
        email: newUser.email,
      },
      JWT_SECRET,
      { expiresIn: JWT_EXPIRES_IN },
    )

    // Return user data with token
    res.status(201).json({
      success: true,
      user: {
        id: newUser.id,
        username: newUser.username,
        email: newUser.email,
        name: newUser.name,
        profilePhoto: newUser.profile_photo,
        token,
        createdAt: newUser.created_at,
      },
    })
  } catch (error) {
    console.error("Registration error:", error)
    res.status(500).json({
      success: false,
      error: "Internal server error",
    })
  }
})

/**
 * POST /api/login
 * Login with username/email + password
 * Works on ANY device - desktop, mobile, tablet
 *
 * Request body:
 * {
 *   "identifier": "john_doe" or "john@example.com",
 *   "password": "securepassword123"
 * }
 *
 * Response:
 * {
 *   "success": true,
 *   "user": {
 *     "id": "uuid",
 *     "username": "john_doe",
 *     "email": "john@example.com",
 *     "name": "John Doe",
 *     "profilePhoto": "base64_data",
 *     "token": "jwt_token"
 *   }
 * }
 */
router.post("/api/login", async (req, res) => {
  try {
    const { identifier, password } = req.body

    // Validate input
    if (!identifier || !password) {
      return res.status(400).json({
        success: false,
        error: "Username/email and password are required",
      })
    }

    // Find user by username OR email
    const result = await db.query(
      `SELECT id, username, email, password_hash, name, profile_photo, created_at
       FROM users
       WHERE username = $1 OR email = $1`,
      [identifier],
    )

    if (result.rows.length === 0) {
      return res.status(401).json({
        success: false,
        error: "Invalid username/email or password",
      })
    }

    const user = result.rows[0]

    // Verify password with bcrypt
    const passwordMatch = await bcrypt.compare(password, user.password_hash)

    if (!passwordMatch) {
      return res.status(401).json({
        success: false,
        error: "Invalid username/email or password",
      })
    }

    // Generate JWT token
    const token = jwt.sign(
      {
        userId: user.id,
        username: user.username,
        email: user.email,
      },
      JWT_SECRET,
      { expiresIn: JWT_EXPIRES_IN },
    )

    // Return user data with token
    res.json({
      success: true,
      user: {
        id: user.id,
        username: user.username,
        email: user.email,
        name: user.name,
        profilePhoto: user.profile_photo,
        token,
        createdAt: user.created_at,
      },
    })
  } catch (error) {
    console.error("Login error:", error)
    res.status(500).json({
      success: false,
      error: "Internal server error",
    })
  }
})

/**
 * GET /api/profile
 * Get current user profile (requires authentication)
 *
 * Headers:
 * Authorization: Bearer <jwt_token>
 *
 * Response:
 * {
 *   "success": true,
 *   "user": {
 *     "id": "uuid",
 *     "username": "john_doe",
 *     "email": "john@example.com",
 *     "name": "John Doe",
 *     "profilePhoto": "base64_data"
 *   }
 * }
 */
router.get("/api/profile", async (req, res) => {
  try {
    // Get token from Authorization header
    const authHeader = req.headers.authorization
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return res.status(401).json({
        success: false,
        error: "No authorization token provided",
      })
    }

    const token = authHeader.substring(7) // Remove 'Bearer ' prefix

    // Verify JWT token
    let decoded
    try {
      decoded = jwt.verify(token, JWT_SECRET)
    } catch (err) {
      return res.status(401).json({
        success: false,
        error: "Invalid or expired token",
      })
    }

    // Get user data from database
    const result = await db.query(
      `SELECT id, username, email, name, profile_photo, created_at
       FROM users
       WHERE id = $1`,
      [decoded.userId],
    )

    if (result.rows.length === 0) {
      return res.status(404).json({
        success: false,
        error: "User not found",
      })
    }

    const user = result.rows[0]

    res.json({
      success: true,
      user: {
        id: user.id,
        username: user.username,
        email: user.email,
        name: user.name,
        profilePhoto: user.profile_photo,
        createdAt: user.created_at,
      },
    })
  } catch (error) {
    console.error("Profile fetch error:", error)
    res.status(500).json({
      success: false,
      error: "Internal server error",
    })
  }
})

/**
 * PUT /api/profile/photo
 * Update user profile photo
 *
 * Headers:
 * Authorization: Bearer <jwt_token>
 *
 * Request body:
 * {
 *   "profilePhoto": "base64_image_data"
 * }
 *
 * Response:
 * {
 *   "success": true,
 *   "profilePhoto": "base64_image_data"
 * }
 */
router.put("/api/profile/photo", async (req, res) => {
  try {
    const authHeader = req.headers.authorization
    if (!authHeader || !authHeader.startsWith("Bearer ")) {
      return res.status(401).json({
        success: false,
        error: "No authorization token provided",
      })
    }

    const token = authHeader.substring(7)
    const decoded = jwt.verify(token, JWT_SECRET)

    const { profilePhoto } = req.body

    if (!profilePhoto) {
      return res.status(400).json({
        success: false,
        error: "Profile photo data is required",
      })
    }

    // Update profile photo in database
    await db.query(
      `UPDATE users SET profile_photo = $1, updated_at = CURRENT_TIMESTAMP
       WHERE id = $2`,
      [profilePhoto, decoded.userId],
    )

    res.json({
      success: true,
      profilePhoto,
    })
  } catch (error) {
    console.error("Profile photo update error:", error)
    res.status(500).json({
      success: false,
      error: "Internal server error",
    })
  }
})

export default router

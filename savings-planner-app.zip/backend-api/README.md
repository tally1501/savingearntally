# Backend API Guide - Cross-Device Authentication System

This guide shows how to implement a production-ready backend API for cross-device authentication that works with the existing frontend code.

## Architecture Overview

```
Frontend (Next.js)          Backend API              Database
    |                           |                        |
    |---> POST /api/register -->|---> INSERT user ---->  |
    |                           |                        |
    |<--- JWT Token -----------|<--- Return user -------|
    |                           |                        |
    |---> POST /api/login ----->|---> QUERY user ------> |
    |                           |                        |
    |<--- JWT Token -----------|<--- Match password ----|
    |                           |                        |
    |---> GET /api/profile ---->|---> VERIFY token ----> |
    |     (with JWT)            |                        |
    |<--- User data -----------|<--- Return data -------|
```

## Cross-Device Support

Once deployed, users can login from ANY device (phone, PC, tablet) because:
- User data is stored in a centralized database (not device-specific storage)
- JWT tokens are stateless and can be validated on any device
- Same credentials work everywhere

## Database Schema

```sql
-- PostgreSQL example
CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  username VARCHAR(50) UNIQUE NOT NULL,
  email VARCHAR(255) UNIQUE NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  name VARCHAR(255),
  profile_photo TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_users_username ON users(username);
CREATE INDEX idx_users_email ON users(email);
```

## Required Environment Variables

Create `.env` file:
```
DATABASE_URL=postgresql://user:password@localhost:5432/savings_db
JWT_SECRET=your_super_secret_jwt_key_change_this_in_production
JWT_EXPIRES_IN=30d
ALLOWED_ORIGINS=http://localhost:3000,https://yourdomain.com
```

## Technology Stack Recommendations

### Backend Framework Options:
1. **Node.js + Express** (Recommended for JavaScript developers)
2. **Next.js API Routes** (Easiest - no separate backend needed)
3. **Node.js + Fastify** (Better performance)
4. **Python + FastAPI** (If you prefer Python)

### Database Options:
1. **PostgreSQL** (Recommended - robust, free, scalable)
2. **MongoDB** (Good for flexible schemas)
3. **MySQL** (Traditional relational database)
4. **Supabase** (PostgreSQL + Auth + Storage - easiest setup)

### Cloud Hosting Options:
1. **Vercel** (Frontend + API Routes - easiest)
2. **Railway** (Backend + Database - simple)
3. **AWS** (Scalable but complex)
4. **DigitalOcean** (Good balance of simplicity and control)

## Implementation Guide

See the following files for complete backend implementation:
- `api-endpoints.ts` - API endpoint examples
- `database-setup.sql` - Database schema and setup
- `auth-middleware.ts` - JWT authentication middleware
- `password-utils.ts` - Password hashing utilities

/**
 * JWT Authentication Middleware
 * Protects API routes that require authentication
 */

import jwt from "jsonwebtoken"
import type { Request, Response, NextFunction } from "express"

const JWT_SECRET = process.env.JWT_SECRET || "your-secret-key"

export interface AuthRequest extends Request {
  user?: {
    userId: string
    username: string
    email: string
  }
}

/**
 * Middleware to verify JWT token
 * Add this to any route that requires authentication
 *
 * Example usage:
 * router.get('/api/protected-route', authenticateToken, (req, res) => {
 *   // req.user contains the decoded token data
 *   res.json({ message: 'This is protected', user: req.user })
 * })
 */
export function authenticateToken(req: AuthRequest, res: Response, next: NextFunction) {
  // Get token from Authorization header
  const authHeader = req.headers["authorization"]
  const token = authHeader && authHeader.split(" ")[1] // Bearer TOKEN

  if (!token) {
    return res.status(401).json({
      success: false,
      error: "Access token required",
    })
  }

  // Verify token
  jwt.verify(token, JWT_SECRET, (err: any, decoded: any) => {
    if (err) {
      return res.status(403).json({
        success: false,
        error: "Invalid or expired token",
      })
    }

    // Attach user info to request
    req.user = {
      userId: decoded.userId,
      username: decoded.username,
      email: decoded.email,
    }

    next()
  })
}

/**
 * Optional middleware to check if token is valid but don't require it
 */
export function optionalAuth(req: AuthRequest, res: Response, next: NextFunction) {
  const authHeader = req.headers["authorization"]
  const token = authHeader && authHeader.split(" ")[1]

  if (token) {
    jwt.verify(token, JWT_SECRET, (err: any, decoded: any) => {
      if (!err) {
        req.user = {
          userId: decoded.userId,
          username: decoded.username,
          email: decoded.email,
        }
      }
    })
  }

  next()
}

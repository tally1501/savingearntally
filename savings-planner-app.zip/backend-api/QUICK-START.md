# Quick Start: Activate Cross-Device Login

## Fastest Way: Use Supabase (5 minutes)

### Step 1: Create Supabase Account
1. Go to [supabase.com](https://supabase.com)
2. Click "Start your project"
3. Sign up (free)

### Step 2: Create Database Table
1. In your Supabase dashboard, go to "SQL Editor"
2. Copy and paste this SQL:

```sql
-- Create users table for cross-device authentication
CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  username TEXT UNIQUE NOT NULL,
  email TEXT UNIQUE NOT NULL,
  password TEXT NOT NULL,
  name TEXT,
  profile_photo TEXT,
  created_at TIMESTAMP DEFAULT NOW()
);

-- Create index for faster lookups
CREATE INDEX idx_users_username ON users(username);
CREATE INDEX idx_users_email ON users(email);
```

3. Click "Run"

### Step 3: Get API Keys
1. Go to Settings > API
2. Copy your:
   - Project URL
   - anon (public) key

### Step 4: Update Your App

Create a `.env.local` file in your project root:
```
NEXT_PUBLIC_SUPABASE_URL=your_project_url_here
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_anon_key_here
```

### Step 5: Install Supabase Client
```bash
npm install @supabase/supabase-js
```

### Step 6: Update Auth Service

I can update the `lib/auth-service.ts` file to use Supabase instead of localStorage.

Just confirm you've completed steps 1-5, and I'll make the code changes for you.

## Alternative: Deploy to Railway (10 minutes)

If you prefer your own backend:

1. Sign up at [railway.app](https://railway.app)
2. Create new project > Add PostgreSQL
3. Note your DATABASE_URL
4. Deploy the backend code from `backend-api` folder
5. Update frontend to use your backend URL

## After Setup

Once configured, your app will:
- Register user once → Saved in cloud database
- Login from phone → Works ✓
- Login from PC → Works ✓
- Login from tablet → Works ✓
- Profile photo synced across all devices ✓

All data will be centralized and accessible from any device with internet connection.

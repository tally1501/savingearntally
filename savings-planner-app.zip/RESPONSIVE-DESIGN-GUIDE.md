# Responsive Design System Documentation

## Overview
This application uses a mobile-first responsive design approach with three main breakpoints optimized for all devices.

## Breakpoint System

### Mobile (≤ 640px)
- **Header Height**: 56px (h-14)
- **Logo Size**: 32px (w-8 h-8)
- **Font Size**: Base 14px
- **Padding**: 12px (px-3)
- **Navigation**: Hamburger menu with slide-down panel
- **Touch Targets**: Minimum 48px for better tap accuracy

### Tablet (641px - 1024px)
- **Header Height**: 64px (h-16)
- **Logo Size**: 40px (w-10 h-10)
- **Font Size**: Base 15px
- **Padding**: 16px (px-4)
- **Navigation**: Compact horizontal with condensed controls
- **Layout**: 2-column grid where applicable

### Desktop (≥ 1025px)
- **Header Height**: 80px (h-20)
- **Logo Size**: 48px (w-12 h-12)
- **Font Size**: Base 16px
- **Padding**: 32px (px-8)
- **Navigation**: Full horizontal navigation with all features visible
- **Layout**: 3-column grid with expanded spacing

## Layout Method Priority

1. **Flexbox** - Primary layout method for header, navigation, and card internals
2. **CSS Grid** - Used for dashboard cards and content grids
3. **Responsive Utilities** - Custom Tailwind classes for device-specific adjustments

## Typography Scale

```css
Mobile:   text-xs (12px), text-sm (14px), text-base (14px)
Tablet:   text-sm (13px), text-base (15px), text-lg (17px)
Desktop:  text-base (16px), text-lg (18px), text-xl (20px), text-2xl (24px)
```

## Header Responsive Behavior

### Mobile Header Features:
- Compact logo with app name only
- Profile photo (32px)
- Hamburger menu icon
- Slide-down menu panel containing:
  - Language toggle
  - Theme toggle
  - Change photo option
  - Logout button

### Tablet Header Features:
- Medium logo with app name and welcome message
- Profile photo (40px)
- Inline language toggle (compact)
- Theme toggle button
- Logout button

### Desktop Header Features:
- Full logo with complete branding
- Profile photo (48px) with hover effects
- Language toggle with labels
- Theme toggle with hover scale animation
- Logout button with text label

## Navigation System

**Mobile**: 
- Hamburger menu (≡) that toggles a slide-down panel
- Touch-friendly 48px minimum hit areas
- Full-width menu items with clear spacing

**Tablet**: 
- Condensed horizontal navigation
- Icon-based controls to save space
- Grouped related actions

**Desktop**:
- Full horizontal navigation bar
- Text labels on all buttons
- Hover effects and animations
- Expanded spacing for mouse interaction

## Image Optimization

- All images use `object-fit: contain` or `cover`
- Maximum width: 100% of container
- Lazy loading enabled for performance
- Responsive sizing: 32px → 40px → 48px (mobile → tablet → desktop)

## Performance Optimizations

1. **Mobile-First Loading**: Base styles loaded first, larger screens enhanced progressively
2. **Touch Optimization**: `-webkit-tap-highlight-color: transparent` for cleaner touch interactions
3. **Smooth Scrolling**: Enabled globally with `scroll-behavior: smooth`
4. **Reduced Motion**: Respects user's motion preferences with `prefers-reduced-motion`
5. **Font Size Lock**: 16px minimum on inputs to prevent iOS zoom on focus

## Testing Checklist

- [ ] Header scales correctly at 320px, 640px, 768px, 1024px, 1440px
- [ ] Hamburger menu opens and closes smoothly on mobile
- [ ] All touch targets are minimum 44px (iOS) / 48px (Android)
- [ ] No horizontal overflow on any screen size
- [ ] Images load and scale properly
- [ ] Typography remains readable at all sizes
- [ ] Navigation is accessible via keyboard and touch
- [ ] Theme toggle works across all breakpoints
- [ ] Profile photo modal opens on all devices

## Implementation Examples

### Responsive Header:
```tsx
{/* Mobile (≤640px) */}
<div className="flex md:hidden h-14 items-center justify-between px-3">
  <Logo size="sm" />
  <HamburgerMenu />
</div>

{/* Tablet (641-1024px) */}
<div className="hidden md:flex lg:hidden h-16 px-4">
  <Logo size="md" />
  <CompactNav />
</div>

{/* Desktop (≥1025px) */}
<div className="hidden lg:flex h-20 px-8">
  <Logo size="lg" />
  <FullNav />
</div>
```

### Responsive Grid:
```tsx
<div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4 md:gap-6">
  {/* Cards automatically reflow */}
</div>
```

## CSS Media Query Reference

```css
/* Mobile First - Base styles apply to mobile */
.element { ... }

/* Tablet and up */
@media (min-width: 641px) { ... }

/* Desktop and up */
@media (min-width: 1025px) { ... }

/* Mobile only */
@media (max-width: 640px) { ... }

/* Tablet only */
@media (min-width: 641px) and (max-width: 1024px) { ... }

import {
  createUserWithEmailAndPassword,
  signInWithEmailAndPassword,
  signOut,
  updateProfile,
  GoogleAuthProvider,
  signInWithPopup,
  onAuthStateChanged,
  type User as FirebaseUser,
} from "firebase/auth"
import { doc, setDoc, getDoc, updateDoc, query, collection, where, getDocs } from "firebase/firestore"
import { ref, uploadString, getDownloadURL } from "firebase/storage"
import { auth, db, storage, isFirebaseConfigured } from "./firebase-config"

export interface User {
  id: string
  username: string
  email: string
  name?: string
  token: string
  createdAt: string
  profilePhoto?: string
}

// Validate email format
export function validateEmail(email: string): boolean {
  const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
  return re.test(email)
}

// Validate username format
export function validateUsername(username: string): boolean {
  const re = /^[a-zA-Z0-9_]{3,20}$/
  return re.test(username)
}

// Compress and resize image
export async function compressImage(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader()
    reader.readAsDataURL(file)
    reader.onload = (event) => {
      const img = document.createElement("img")
      img.src = event.target?.result as string
      img.onload = () => {
        const canvas = document.createElement("canvas")
        const MAX_WIDTH = 400
        const MAX_HEIGHT = 400
        let width = img.width
        let height = img.height

        if (width > height) {
          if (width > MAX_WIDTH) {
            height *= MAX_WIDTH / width
            width = MAX_WIDTH
          }
        } else {
          if (height > MAX_HEIGHT) {
            width *= MAX_HEIGHT / height
            height = MAX_HEIGHT
          }
        }

        canvas.width = width
        canvas.height = height
        const ctx = canvas.getContext("2d")
        ctx?.drawImage(img, 0, 0, width, height)

        resolve(canvas.toDataURL("image/jpeg", 0.7))
      }
      img.onerror = reject
    }
    reader.onerror = reject
  })
}

// Generate default avatar
export function getDefaultAvatar(username: string): string {
  return `https://api.dicebear.com/7.x/avataaars/svg?seed=${encodeURIComponent(username)}`
}

// Convert Firebase User to App User
async function convertFirebaseUser(firebaseUser: FirebaseUser): Promise<User> {
  const userDoc = await getDoc(doc(db, "users", firebaseUser.uid))
  const userData = userDoc.data()

  return {
    id: firebaseUser.uid,
    username: userData?.username || firebaseUser.email?.split("@")[0] || "user",
    email: firebaseUser.email || "",
    name: firebaseUser.displayName || userData?.name || "",
    token: await firebaseUser.getIdToken(),
    createdAt: userData?.createdAt || new Date().toISOString(),
    profilePhoto: firebaseUser.photoURL || userData?.profilePhoto || getDefaultAvatar(userData?.username || "user"),
  }
}

const USERS_KEY = "savings_app_users"
const CURRENT_USER_KEY = "savings_app_current_user"

function getUsersFromLocalStorage(): any[] {
  if (typeof window === "undefined") return []
  const users = localStorage.getItem(USERS_KEY)
  return users ? JSON.parse(users) : []
}

function saveUsersToLocalStorage(users: any[]): void {
  if (typeof window === "undefined") return
  localStorage.setItem(USERS_KEY, JSON.stringify(users))
}

function saveCurrentUserToLocalStorage(user: User | null): void {
  if (typeof window === "undefined") return
  if (user) {
    localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(user))
  } else {
    localStorage.removeItem(CURRENT_USER_KEY)
  }
}

function getCurrentUserFromLocalStorage(): User | null {
  if (typeof window === "undefined") return null
  const user = localStorage.getItem(CURRENT_USER_KEY)
  return user ? JSON.parse(user) : null
}

// Hash password (simple SHA-256 for localStorage fallback)
async function hashPassword(password: string): Promise<string> {
  const encoder = new TextEncoder()
  const data = encoder.encode(password)
  const hashBuffer = await crypto.subtle.digest("SHA-256", data)
  const hashArray = Array.from(new Uint8Array(hashBuffer))
  return hashArray.map((b) => b.toString(16).padStart(2, "0")).join("")
}

// Register new user with Firebase or localStorage fallback
export async function registerUser(data: {
  username: string
  email: string
  password: string
  name?: string
  profilePhoto?: string
}): Promise<{ success: boolean; user?: User; error?: string }> {
  try {
    // Validate inputs
    if (!validateUsername(data.username)) {
      return { success: false, error: "Username harus 3-20 karakter (huruf, angka, underscore)" }
    }

    if (!validateEmail(data.email)) {
      return { success: false, error: "Format email tidak valid" }
    }

    if (data.password.length < 8) {
      return { success: false, error: "Password minimal 8 karakter" }
    }

    if (isFirebaseConfigured && auth && db && storage) {
      // Check if username already exists in Firestore
      const usernameQuery = query(collection(db, "users"), where("username", "==", data.username))
      const usernameSnapshot = await getDocs(usernameQuery)

      if (!usernameSnapshot.empty) {
        return { success: false, error: "Username sudah terdaftar" }
      }

      // Create Firebase Auth user
      const userCredential = await createUserWithEmailAndPassword(auth, data.email, data.password)
      const firebaseUser = userCredential.user

      // Upload profile photo to Firebase Storage if provided
      let photoURL = data.profilePhoto || getDefaultAvatar(data.username)
      if (data.profilePhoto && data.profilePhoto.startsWith("data:image")) {
        const photoRef = ref(storage, `profile-photos/${firebaseUser.uid}`)
        await uploadString(photoRef, data.profilePhoto, "data_url")
        photoURL = await getDownloadURL(photoRef)
      }

      // Update Firebase Auth profile
      await updateProfile(firebaseUser, {
        displayName: data.name || data.username,
        photoURL,
      })

      // Store additional user data in Firestore
      await setDoc(doc(db, "users", firebaseUser.uid), {
        username: data.username,
        email: data.email,
        name: data.name || data.username,
        profilePhoto: photoURL,
        createdAt: new Date().toISOString(),
      })

      // Convert to app user format
      const user = await convertFirebaseUser(firebaseUser)

      return { success: true, user }
    } else {
      // localStorage fallback
      const users = getUsersFromLocalStorage()

      // Check if username or email already exists
      if (users.some((u: any) => u.username === data.username)) {
        return { success: false, error: "Username sudah terdaftar" }
      }

      if (users.some((u: any) => u.email === data.email)) {
        return { success: false, error: "Email sudah terdaftar" }
      }

      // Create new user
      const hashedPassword = await hashPassword(data.password)
      const newUser: User = {
        id: `user_${Date.now()}`,
        username: data.username,
        email: data.email,
        name: data.name || data.username,
        token: `token_${Date.now()}`,
        createdAt: new Date().toISOString(),
        profilePhoto: data.profilePhoto || getDefaultAvatar(data.username),
      }

      users.push({ ...newUser, password: hashedPassword })
      saveUsersToLocalStorage(users)
      saveCurrentUserToLocalStorage(newUser)

      return { success: true, user: newUser }
    }
  } catch (error: any) {
    console.error("[Auth] Registration error:", error)

    // Handle Firebase-specific errors
    if (error.code === "auth/email-already-in-use") {
      return { success: false, error: "Email sudah terdaftar" }
    } else if (error.code === "auth/weak-password") {
      return { success: false, error: "Password terlalu lemah" }
    } else if (error.code === "auth/invalid-email") {
      return { success: false, error: "Format email tidak valid" }
    }

    return { success: false, error: "Gagal mendaftar. Silakan coba lagi." }
  }
}

// Login with email/username and password
export async function loginUser(
  identifier: string,
  password: string,
): Promise<{ success: boolean; user?: User; error?: string }> {
  try {
    if (isFirebaseConfigured && auth && db) {
      let email = identifier

      // If identifier is username, fetch email from Firestore
      if (!identifier.includes("@")) {
        const usernameQuery = query(collection(db, "users"), where("username", "==", identifier))
        const usernameSnapshot = await getDocs(usernameQuery)

        if (usernameSnapshot.empty) {
          return { success: false, error: "Username tidak ditemukan" }
        }

        const userData = usernameSnapshot.docs[0].data()
        email = userData.email
      }

      // Sign in with Firebase
      const userCredential = await signInWithEmailAndPassword(auth, email, password)
      const user = await convertFirebaseUser(userCredential.user)

      return { success: true, user }
    } else {
      // localStorage fallback
      const users = getUsersFromLocalStorage()
      const hashedPassword = await hashPassword(password)

      const user = users.find(
        (u: any) => (u.username === identifier || u.email === identifier) && u.password === hashedPassword,
      )

      if (!user) {
        return { success: false, error: "Username/Email atau password salah" }
      }

      const { password: _, ...userWithoutPassword } = user
      saveCurrentUserToLocalStorage(userWithoutPassword)

      return { success: true, user: userWithoutPassword }
    }
  } catch (error: any) {
    console.error("[Auth] Login error:", error)

    if (
      error.code === "auth/invalid-credential" ||
      error.code === "auth/user-not-found" ||
      error.code === "auth/wrong-password"
    ) {
      return { success: false, error: "Username/Email atau password salah" }
    } else if (error.code === "auth/too-many-requests") {
      return { success: false, error: "Terlalu banyak percobaan login. Coba lagi nanti." }
    }

    return { success: false, error: "Gagal login. Silakan coba lagi." }
  }
}

// Login with Google OAuth
export async function loginWithGoogle(): Promise<{ success: boolean; user?: User; error?: string }> {
  try {
    const provider = new GoogleAuthProvider()
    const userCredential = await signInWithPopup(auth, provider)
    const firebaseUser = userCredential.user

    // Check if user document exists in Firestore
    const userDoc = await getDoc(doc(db, "users", firebaseUser.uid))

    if (!userDoc.exists()) {
      // Create user document for new Google users
      const username = firebaseUser.email?.split("@")[0] || `user${Date.now()}`
      await setDoc(doc(db, "users", firebaseUser.uid), {
        username,
        email: firebaseUser.email,
        name: firebaseUser.displayName,
        profilePhoto: firebaseUser.photoURL || getDefaultAvatar(username),
        createdAt: new Date().toISOString(),
      })
    }

    const user = await convertFirebaseUser(firebaseUser)
    return { success: true, user }
  } catch (error: any) {
    console.error("[Auth] Google login error:", error)

    if (error.code === "auth/popup-closed-by-user") {
      return { success: false, error: "Login dibatalkan" }
    }

    return { success: false, error: "Gagal login dengan Google" }
  }
}

// Update profile photo
export async function updateProfilePhoto(photoData: string): Promise<{ success: boolean; error?: string }> {
  try {
    if (isFirebaseConfigured && auth && db && storage) {
      const user = auth.currentUser
      if (!user) return { success: false, error: "User not logged in" }

      // Upload to Firebase Storage
      const photoRef = ref(storage, `profile-photos/${user.uid}`)
      await uploadString(photoRef, photoData, "data_url")
      const photoURL = await getDownloadURL(photoRef)

      // Update Firebase Auth profile
      await updateProfile(user, { photoURL })

      // Update Firestore document
      await updateDoc(doc(db, "users", user.uid), {
        profilePhoto: photoURL,
      })

      return { success: true }
    } else {
      // localStorage fallback
      const currentUser = getCurrentUserFromLocalStorage()
      if (!currentUser) return { success: false, error: "User not logged in" }

      const users = getUsersFromLocalStorage()
      const userIndex = users.findIndex((u: any) => u.id === currentUser.id)

      if (userIndex !== -1) {
        users[userIndex].profilePhoto = photoData
        saveUsersToLocalStorage(users)

        currentUser.profilePhoto = photoData
        saveCurrentUserToLocalStorage(currentUser)

        return { success: true }
      }

      return { success: false, error: "User not found" }
    }
  } catch (error) {
    console.error("[Auth] Update photo error:", error)
    return { success: false, error: "Gagal memperbarui foto profil" }
  }
}

// Get current authenticated user
export async function getCurrentUser(): Promise<User | null> {
  if (isFirebaseConfigured && auth) {
    return new Promise((resolve) => {
      const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
        unsubscribe()

        if (firebaseUser) {
          try {
            const user = await convertFirebaseUser(firebaseUser)
            resolve(user)
          } catch (error) {
            console.error("[Auth] Get current user error:", error)
            resolve(null)
          }
        } else {
          resolve(null)
        }
      })
    })
  } else {
    // localStorage fallback
    return getCurrentUserFromLocalStorage()
  }
}

// Logout user
export async function logoutUser(): Promise<void> {
  if (isFirebaseConfigured && auth) {
    await signOut(auth)
  } else {
    // localStorage fallback
    saveCurrentUserToLocalStorage(null)
  }
}

// Listen to auth state changes
export function onAuthChange(callback: (user: User | null) => void): () => void {
  return onAuthStateChanged(auth, async (firebaseUser) => {
    if (firebaseUser) {
      try {
        const user = await convertFirebaseUser(firebaseUser)
        callback(user)
      } catch (error) {
        console.error("[Auth] Auth state change error:", error)
        callback(null)
      }
    } else {
      callback(null)
    }
  })
}

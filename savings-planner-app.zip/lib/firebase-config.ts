// Firebase Configuration
import { initializeApp, getApps, getApp, type FirebaseApp } from "firebase/app"
import { getAuth, type Auth } from "firebase/auth"
import { getFirestore, type Firestore } from "firebase/firestore"
import { getStorage, type FirebaseStorage } from "firebase/storage"

// Firebase configuration
// IMPORTANT: Replace these with your actual Firebase project credentials
// Get these from: Firebase Console > Project Settings > General > Your apps
const firebaseConfig = {
  apiKey: process.env.NEXT_PUBLIC_FIREBASE_API_KEY || "",
  authDomain: process.env.NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN || "",
  projectId: process.env.NEXT_PUBLIC_FIREBASE_PROJECT_ID || "",
  storageBucket: process.env.NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET || "",
  messagingSenderId: process.env.NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID || "",
  appId: process.env.NEXT_PUBLIC_FIREBASE_APP_ID || "",
}

const isFirebaseConfigured = firebaseConfig.apiKey && firebaseConfig.projectId

let app: FirebaseApp | null = null
let auth: Auth | null = null
let db: Firestore | null = null
let storage: FirebaseStorage | null = null

if (isFirebaseConfigured) {
  try {
    // Initialize Firebase (singleton pattern)
    app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApp()

    // Initialize Firebase services
    auth = getAuth(app)
    db = getFirestore(app)
    storage = getStorage(app)

    console.log("[Firebase] Firebase initialized successfully")
  } catch (error) {
    console.error("[Firebase] Failed to initialize Firebase:", error)
  }
} else {
  console.warn(
    "[Firebase] Firebase not configured. Using localStorage fallback. Add your Firebase credentials to .env.local to enable cross-device sync.",
  )
}

export { auth, db, storage, isFirebaseConfigured }
export default app

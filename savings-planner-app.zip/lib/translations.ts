export const translations = {
  id: {
    tooManyAttempts: "Terlalu banyak percobaan. Tunggu 30 detik.",
    attemptRemaining: "percobaan tersisa",
  },
  en: {
    tooManyAttempts: "Too many attempts. Wait 30 seconds.",
    attemptRemaining: "attempts remaining",
  },
}

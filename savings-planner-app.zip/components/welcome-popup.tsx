"use client"

import type React from "react"
import { useEffect, useState } from "react"
import { X } from "lucide-react"

interface WelcomePopupProps {
  username: string
  onClose: () => void
  isDark: boolean
  language: "id" | "en"
}

const translations = {
  id: {
    motivationalMessage: "Semangat menabung",
    continueButton: "Lanjutkan ke Dashboard",
  },
  en: {
    motivationalMessage: "Keep saving",
    continueButton: "Continue to Dashboard",
  },
}

export default function WelcomePopup({ username, onClose, isDark, language }: WelcomePopupProps) {
  const t = translations[language]
  const [isVisible, setIsVisible] = useState(false)
  const [showText, setShowText] = useState(false)

  useEffect(() => {
    console.log("[v0] Welcome popup mounted for user:", username)

    setTimeout(() => setIsVisible(true), 100)

    // Trigger text animation after popup zoom completes
    setTimeout(() => setShowText(true), 700)
  }, [username])

  const handleClose = () => {
    console.log("[v0] Welcome popup closing")
    setIsVisible(false)
    setTimeout(onClose, 300)
  }

  const handleOverlayClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget) {
      handleClose()
    }
  }

  return (
    <div
      className={`fixed inset-0 z-50 flex items-center justify-center p-4 transition-opacity duration-300 ${
        isVisible ? "opacity-100" : "opacity-0"
      }`}
      onClick={handleOverlayClick}
    >
      {/* Semi-transparent overlay */}
      <div className="absolute inset-0 bg-black/70 backdrop-blur-md" />

      {/* Popup container with zoom animation */}
      <div
        className={`relative bg-gradient-to-br from-gray-900 via-purple-900/50 to-blue-900/50 dark:from-gray-950 dark:via-purple-950/50 dark:to-blue-950/50 rounded-3xl shadow-2xl max-w-lg w-full overflow-hidden transform transition-all duration-500 border border-purple-500/30 ${
          isVisible ? "scale-100 opacity-100" : "scale-60 opacity-0"
        }`}
        style={{
          animation: isVisible ? "popupZoom 0.5s cubic-bezier(0.34, 1.56, 0.64, 1)" : "none",
        }}
      >
        {/* Close button */}
        <button
          onClick={handleClose}
          className="absolute top-4 right-4 z-10 w-10 h-10 flex items-center justify-center bg-white/10 backdrop-blur-sm rounded-full hover:bg-white/20 transition-all duration-300 border border-white/20 hover:border-white/40 shadow-lg hover:shadow-purple-500/50"
          aria-label="Close"
        >
          <X className="w-5 h-5 text-white" />
        </button>

        {/* Character image with neon glow effect */}
        <div className="relative pt-8 px-6 flex items-center justify-center">
          <div
            className="relative"
            style={{
              filter: "drop-shadow(0 0 30px rgba(168, 85, 247, 0.6)) drop-shadow(0 0 60px rgba(59, 130, 246, 0.4))",
            }}
          >
            <img
              src="/images/welcome-character.png"
              alt="Welcome character with money"
              className="w-full h-auto object-contain neon-character"
              style={{ maxHeight: "350px" }}
            />
          </div>

          {/* Animated text appearing from hands area */}
          <div
            className={`absolute bottom-4 left-1/2 transform -translate-x-1/2 transition-all duration-700 ${
              showText ? "translate-y-0 opacity-100 scale-100" : "translate-y-12 opacity-0 scale-90"
            }`}
            style={{
              animation: showText ? "textSlideUp 0.7s cubic-bezier(0.34, 1.56, 0.64, 1)" : "none",
            }}
          >
            <div
              className="relative bg-gradient-to-r from-purple-600 via-pink-500 to-blue-600 text-white px-6 py-3 rounded-2xl backdrop-blur-sm border border-white/20"
              style={{
                boxShadow:
                  "0 0 20px rgba(168, 85, 247, 0.6), 0 0 40px rgba(236, 72, 153, 0.4), 0 0 60px rgba(59, 130, 246, 0.3)",
              }}
            >
              <p className="text-base md:text-lg font-bold text-center whitespace-nowrap text-shadow-neon">
                {t.motivationalMessage}, {username}!
              </p>
              <div
                className="absolute inset-0 bg-gradient-to-r from-purple-500 via-pink-500 to-blue-500 rounded-2xl blur-xl opacity-50 -z-10"
                style={{ transform: "scale(1.1)" }}
              />
            </div>
          </div>
        </div>

        {/* Continue button */}
        <div className="p-6 pt-20">
          <button
            onClick={handleClose}
            className="w-full bg-gradient-to-r from-purple-600 via-pink-500 to-blue-600 hover:from-purple-700 hover:via-pink-600 hover:to-blue-700 text-white font-bold py-4 rounded-xl transition-all duration-300 transform hover:scale-105 border border-white/20 hover:border-white/40"
            style={{
              boxShadow:
                "0 0 20px rgba(168, 85, 247, 0.5), 0 0 30px rgba(236, 72, 153, 0.3), 0 4px 20px rgba(0, 0, 0, 0.3)",
            }}
          >
            {t.continueButton}
          </button>
        </div>
      </div>

      <style jsx>{`
        @keyframes popupZoom {
          0% {
            transform: scale(0.6);
            opacity: 0;
          }
          100% {
            transform: scale(1);
            opacity: 1;
          }
        }

        @keyframes textSlideUp {
          0% {
            transform: translateX(-50%) translateY(48px) scale(0.9);
            opacity: 0;
          }
          100% {
            transform: translateX(-50%) translateY(0) scale(1);
            opacity: 1;
          }
        }

        .neon-character {
          animation: neonPulse 2s ease-in-out infinite;
        }

        @keyframes neonPulse {
          0%,
          100% {
            filter: drop-shadow(0 0 25px rgba(168, 85, 247, 0.6)) drop-shadow(0 0 50px rgba(59, 130, 246, 0.4));
          }
          50% {
            filter: drop-shadow(0 0 35px rgba(168, 85, 247, 0.8)) drop-shadow(0 0 70px rgba(59, 130, 246, 0.6));
          }
        }

        .text-shadow-neon {
          text-shadow: 0 0 10px rgba(255, 255, 255, 0.8), 0 0 20px rgba(168, 85, 247, 0.6),
            0 0 30px rgba(236, 72, 153, 0.4);
        }
      `}</style>
    </div>
  )
}

"use client"

import type React from "react"
import { useState, useRef } from "react"
import Image from "next/image"
import { Eye, EyeOff, Mail, Lock, UserIcon, Globe, Camera, Loader2 } from "lucide-react"
import { Button } from "@/components/ui/button"
import { registerUser, loginUser, compressImage, getDefaultAvatar, type User } from "@/lib/auth-service"

type AuthMode = "login" | "register"
type Language = "id" | "en"

interface AuthPageProps {
  onLogin: (user: User) => void
  isDark: boolean
  language: Language
  setIsDark: (isDark: boolean) => void
  setLanguage: (language: Language) => void
}

const translations = {
  id: {
    welcome: "Selamat Datang",
    login: "Masuk",
    register: "Daftar",
    username: "Username",
    email: "Email",
    password: "Password",
    name: "Nama Lengkap (Opsional)",
    loginButton: "Masuk",
    registerButton: "Daftar Akun",
    usernameOrEmail: "Username atau Email",
    dontHaveAccount: "Belum punya akun?",
    alreadyHaveAccount: "Sudah punya akun?",
    registerHere: "Daftar di sini",
    loginHere: "Masuk di sini",
    passwordMin: "Minimal 8 karakter",
    usernameFormat: "3-20 karakter (huruf, angka, _)",
    emailRequired: "Email harus diisi",
    usernameRequired: "Username harus diisi",
    passwordRequired: "Password minimal 8 karakter",
    invalidEmail: "Format email tidak valid",
    invalidUsername: "Username tidak valid",
    loginSuccess: "Berhasil masuk!",
    registerSuccess: "Berhasil mendaftar!",
    loginAnywhere: "Login dari HP, PC, atau tablet mana pun menggunakan username atau email Anda",
    uploadPhoto: "Upload foto profil (opsional)",
    fileTooLarge: "Ukuran file maksimal 5MB",
    invalidFileType: "File harus berupa gambar",
    imageProcessingError: "Gagal memproses gambar",
    tooManyAttempts: "Terlalu banyak percobaan. Tunggu 30 detik.",
    allFieldsRequired: "Semua field harus diisi.",
    passwordMismatch: "Password tidak cocok.",
    passwordTooShort: "Password terlalu pendek.",
    usernameOrEmailPlaceholder: "username atau email@example.com",
    passwordPlaceholder: "••••••••",
    loading: "Loading...",
  },
  en: {
    welcome: "Welcome",
    login: "Login",
    register: "Sign Up",
    username: "Username",
    email: "Email",
    password: "Password",
    name: "Full Name (Optional)",
    loginButton: "Sign In",
    registerButton: "Create Account",
    usernameOrEmail: "Username or Email",
    dontHaveAccount: "Don't have an account?",
    alreadyHaveAccount: "Already have an account?",
    registerHere: "Sign up here",
    loginHere: "Sign in here",
    passwordMin: "Minimum 8 characters",
    usernameFormat: "3-20 characters (letters, numbers, _)",
    emailRequired: "Email is required",
    usernameRequired: "Username is required",
    passwordRequired: "Password minimum 8 characters",
    invalidEmail: "Invalid email format",
    invalidUsername: "Invalid username",
    loginSuccess: "Successfully logged in!",
    registerSuccess: "Successfully registered!",
    loginAnywhere: "Login from any phone, PC, or tablet using your username or email",
    uploadPhoto: "Upload profile photo (optional)",
    fileTooLarge: "Maximum file size is 5MB",
    invalidFileType: "File must be an image",
    imageProcessingError: "Failed to process image",
    tooManyAttempts: "Too many attempts. Please wait 30 seconds.",
    allFieldsRequired: "All fields are required.",
    passwordMismatch: "Passwords do not match.",
    passwordTooShort: "Password is too short.",
    usernameOrEmailPlaceholder: "username_or_email@example.com",
    passwordPlaceholder: "••••••••",
    loading: "Loading...",
  },
}

export default function AuthPage({ onLogin, isDark, language, setIsDark, setLanguage }: AuthPageProps) {
  const t = translations[language]

  const [mode, setMode] = useState<"login" | "register">("login")
  const [loginIdentifier, setLoginIdentifier] = useState("")
  const [loginPassword, setLoginPassword] = useState("")
  const [username, setUsername] = useState("")
  const [email, setEmail] = useState("")
  const [name, setName] = useState("")
  const [password, setPassword] = useState("")
  const [confirmPassword, setConfirmPassword] = useState("")
  const [showPassword, setShowPassword] = useState(false)
  const [profilePhoto, setProfilePhoto] = useState<string>("")
  const [error, setError] = useState("")
  const [success, setSuccess] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [loginAttempts, setLoginAttempts] = useState(0)
  const [isLockedOut, setIsLockedOut] = useState(false)
  const loginIdentifierRef = useRef<HTMLInputElement>(null)

  const neonGlow = isDark ? "shadow-[0_0_20px_rgba(0,212,255,0.6)]" : "shadow-[0_0_15px_rgba(0,149,255,0.4)]"

  const handleInputChange = (setter: React.Dispatch<React.SetStateAction<string>>, value: string) => {
    setter(value)
    if (error) setError("")
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setSuccess("")

    if (isLockedOut) {
      setError(t.tooManyAttempts || "Terlalu banyak percobaan. Tunggu 30 detik.")
      return
    }

    if (!loginIdentifier) {
      setError(t.usernameRequired)
      loginIdentifierRef.current?.focus()
      return
    }

    if (loginPassword.length < 8) {
      setError(t.passwordRequired)
      return
    }

    setIsLoading(true)

    await new Promise((resolve) => setTimeout(resolve, 500))

    const result = await loginUser(loginIdentifier, loginPassword)

    setIsLoading(false)

    if (result.success && result.user) {
      setSuccess(t.loginSuccess)
      setLoginAttempts(0)
      setTimeout(() => onLogin(result.user!), 500)
    } else {
      const newAttempts = loginAttempts + 1
      setLoginAttempts(newAttempts)

      setError(result.error || "Username/Email atau password salah. Silakan coba lagi.")

      if (newAttempts >= 5) {
        setIsLockedOut(true)
        setError("Terlalu banyak percobaan login gagal. Tunggu 30 detik sebelum mencoba lagi.")

        setTimeout(() => {
          setIsLockedOut(false)
          setLoginAttempts(0)
          setError("")
        }, 30000)
      }

      setTimeout(() => loginIdentifierRef.current?.focus(), 100)
    }
  }

  const handlePhotoUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    if (file.size > 5 * 1024 * 1024) {
      setError(t.fileTooLarge)
      return
    }

    if (!file.type.startsWith("image/")) {
      setError(t.invalidFileType)
      return
    }

    try {
      const compressedImage = await compressImage(file)
      setProfilePhoto(compressedImage)
      setPhotoPreview(compressedImage)
    } catch (error) {
      setError(t.imageProcessingError)
    }
  }

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setSuccess("")

    if (!username || !email || !password) {
      setError(t.allFieldsRequired)
      return
    }

    if (password !== confirmPassword) {
      setError(t.passwordMismatch)
      return
    }

    if (password.length < 8) {
      setError(t.passwordTooShort)
      return
    }

    setIsLoading(true)

    await new Promise((resolve) => setTimeout(resolve, 500))

    const result = await registerUser({
      username,
      email,
      password,
      name,
      profilePhoto,
    })

    setIsLoading(false)

    if (result.success && result.user) {
      setSuccess(t.registerSuccess)
      setTimeout(() => onLogin(result.user!), 500)
    } else {
      setError(result.error || "Registrasi gagal. Silakan coba lagi.")
    }
  }

  const [photoPreview, setPhotoPreview] = useState<string>("")

  return (
    <div
      className={`min-h-screen flex items-center justify-center p-4 transition-colors duration-500 ${
        isDark
          ? "bg-gradient-to-br from-[#0a0e27] via-[#1a1a2e] to-[#16213e]"
          : "bg-gradient-to-br from-blue-50 via-white to-cyan-50"
      }`}
    >
      {/* Language and Theme Toggle */}
      <div className="absolute top-4 right-4 flex items-center gap-2 sm:gap-3">
        <Button
          variant="ghost"
          size="sm"
          onClick={() => setLanguage(language === "id" ? "en" : "id")}
          className={`text-xs sm:text-sm ${isDark ? "text-white hover:bg-white/10" : "text-gray-700 hover:bg-gray-100"}`}
        >
          <Globe className="w-4 h-4 mr-1 sm:mr-2" />
          {language === "id" ? "ID" : "EN"}
        </Button>

        <Button
          variant="ghost"
          size="sm"
          onClick={() => setIsDark(!isDark)}
          className={`text-xs sm:text-sm ${isDark ? "text-white hover:bg-white/10" : "text-gray-700 hover:bg-gray-100"}`}
        >
          {isDark ? "☀️" : "🌙"}
        </Button>
      </div>

      {/* Auth Card */}
      <div
        className={`w-full max-w-md p-6 sm:p-8 rounded-3xl transition-all duration-500 ${
          isDark
            ? "bg-gradient-to-br from-gray-900/90 to-gray-800/90 backdrop-blur-lg border border-cyan-500/30"
            : "bg-white/90 backdrop-blur-lg border border-blue-200 shadow-2xl"
        } ${neonGlow}`}
      >
        {/* Logo */}
        <div className="flex justify-center mb-6">
          <Image
            src="/images/api-attachments-bx4bhnk5pzjvdxoq0v9or.png"
            alt="Saving Earn Logo"
            width={100}
            height={100}
            className="rounded-2xl"
          />
        </div>

        {/* Title */}
        <h1 className={`text-2xl sm:text-3xl font-bold text-center mb-2 ${isDark ? "text-white" : "text-gray-900"}`}>
          {mode === "login" ? t.welcome : t.register}
        </h1>
        <p className={`text-center mb-6 text-sm sm:text-base ${isDark ? "text-gray-400" : "text-gray-600"}`}>
          Saving Earn By Ellycal
        </p>

        {/* Info message for cross-device login */}
        {mode === "login" && (
          <div
            className={`mb-6 p-3 rounded-lg text-xs sm:text-sm text-center ${
              isDark
                ? "bg-cyan-500/10 border border-cyan-500/30 text-cyan-300"
                : "bg-blue-50 border border-blue-200 text-blue-700"
            }`}
          >
            {t.loginAnywhere}
          </div>
        )}

        {/* Error/Success Messages */}
        {error && (
          <div className="mb-4 p-3 rounded-lg bg-red-500/20 border border-red-500/50 text-red-500 text-sm">{error}</div>
        )}
        {success && (
          <div className="mb-4 p-3 rounded-lg bg-green-500/20 border border-green-500/50 text-green-500 text-sm">
            {success}
          </div>
        )}

        {/* Login Form */}
        {mode === "login" && (
          <form onSubmit={handleSubmit} className="space-y-5">
            <div>
              <label className={`block text-sm font-semibold mb-2 ${isDark ? "text-gray-300" : "text-gray-700"}`}>
                {t.usernameOrEmail}
              </label>
              <div className="relative group">
                <Mail
                  className={`absolute left-4 top-1/2 -translate-y-1/2 transition-all ${
                    isDark
                      ? "text-gray-400 group-focus-within:text-cyan-400"
                      : "text-gray-500 group-focus-within:text-blue-500"
                  }`}
                  size={20}
                />
                <input
                  ref={loginIdentifierRef}
                  type="text"
                  value={loginIdentifier}
                  onChange={(e) => handleInputChange(setLoginIdentifier, e.target.value)}
                  className={`w-full pl-12 pr-4 py-3.5 rounded-xl border-2 transition-all font-medium text-base
                    ${
                      isDark
                        ? "bg-gray-800/50 border-gray-700 text-white focus:border-cyan-500 focus:bg-gray-800"
                        : "bg-white border-gray-300 text-gray-900 focus:border-blue-500"
                    }
                    focus:outline-none focus:ring-2 ${isDark ? "focus:ring-cyan-500/20" : "focus:ring-blue-500/20"}
                  `}
                  placeholder={t.usernameOrEmailPlaceholder}
                  disabled={isLoading || isLockedOut}
                  autoComplete="username"
                />
              </div>
            </div>

            <div>
              <label className={`block text-sm font-semibold mb-2 ${isDark ? "text-gray-300" : "text-gray-700"}`}>
                {t.password}
              </label>
              <div className="relative group">
                <Lock
                  className={`absolute left-4 top-1/2 -translate-y-1/2 transition-all ${
                    isDark
                      ? "text-gray-400 group-focus-within:text-cyan-400"
                      : "text-gray-500 group-focus-within:text-blue-500"
                  }`}
                  size={20}
                />
                <input
                  type={showPassword ? "text" : "password"}
                  value={loginPassword}
                  onChange={(e) => handleInputChange(setLoginPassword, e.target.value)}
                  className={`w-full pl-12 pr-12 py-3.5 rounded-xl border-2 transition-all font-medium text-base
                    ${
                      isDark
                        ? "bg-gray-800/50 border-gray-700 text-white focus:border-cyan-500 focus:bg-gray-800"
                        : "bg-white border-gray-300 text-gray-900 focus:border-blue-500"
                    }
                    focus:outline-none focus:ring-2 ${isDark ? "focus:ring-cyan-500/20" : "focus:ring-blue-500/20"}
                  `}
                  placeholder={t.passwordPlaceholder}
                  disabled={isLoading || isLockedOut}
                  autoComplete="current-password"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className={`absolute right-4 top-1/2 -translate-y-1/2 transition-colors ${
                    isDark ? "text-gray-400 hover:text-cyan-400" : "text-gray-500 hover:text-blue-500"
                  }`}
                  disabled={isLoading || isLockedOut}
                >
                  {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
                </button>
              </div>
            </div>

            <button
              type="submit"
              disabled={isLoading || isLockedOut}
              className={`w-full py-3.5 rounded-xl font-bold text-base transition-all transform hover:scale-[1.02] active:scale-[0.98]
                ${
                  isDark
                    ? "bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-600 hover:to-blue-600 text-white"
                    : "bg-gradient-to-r from-blue-500 to-indigo-500 hover:from-blue-600 hover:to-indigo-600 text-white"
                }
                disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none
                ${neonGlow}
              `}
            >
              {isLoading ? (
                <span className="flex items-center justify-center gap-2">
                  <Loader2 className="animate-spin" size={20} />
                  {t.loading}
                </span>
              ) : (
                t.login
              )}
            </button>

            {loginAttempts > 0 && loginAttempts < 5 && (
              <p className="text-xs text-center text-yellow-500">
                {language === "id"
                  ? `Percobaan ${loginAttempts}/5. ${5 - loginAttempts} percobaan tersisa.`
                  : `Attempt ${loginAttempts}/5. ${5 - loginAttempts} attempts remaining.`}
              </p>
            )}

            <p className={`text-center text-sm ${isDark ? "text-gray-400" : "text-gray-600"}`}>
              {t.dontHaveAccount}{" "}
              <button
                type="button"
                onClick={() => setMode("register")}
                className={`font-semibold ${isDark ? "text-cyan-400 hover:text-cyan-300" : "text-blue-600 hover:text-blue-700"}`}
              >
                {t.registerHere}
              </button>
            </p>
          </form>
        )}

        {/* Register Form */}
        {mode === "register" && (
          <form onSubmit={handleRegister} className="space-y-4">
            <div className="flex flex-col items-center mb-4">
              <div className="relative">
                <div
                  className={`w-24 h-24 rounded-full overflow-hidden border-4 ${
                    isDark ? "border-cyan-500/30" : "border-blue-200"
                  }`}
                >
                  {photoPreview ? (
                    <img
                      src={photoPreview || "/placeholder.svg"}
                      alt="Profile preview"
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <img
                      src={getDefaultAvatar(username || "user")}
                      alt="Default avatar"
                      className="w-full h-full object-cover"
                    />
                  )}
                </div>
                <label
                  htmlFor="photo-upload"
                  className={`absolute bottom-0 right-0 p-2 rounded-full cursor-pointer transition-all ${
                    isDark ? "bg-cyan-500 hover:bg-cyan-600 text-white" : "bg-blue-500 hover:bg-blue-600 text-white"
                  }`}
                >
                  <Camera className="w-4 h-4" />
                  <input
                    id="photo-upload"
                    type="file"
                    accept="image/*"
                    onChange={handlePhotoUpload}
                    className="hidden"
                  />
                </label>
              </div>
              <p className={`text-xs mt-2 text-center ${isDark ? "text-gray-400" : "text-gray-600"}`}>
                {t.uploadPhoto}
              </p>
            </div>

            <div>
              <label className={`block text-sm font-semibold mb-2 ${isDark ? "text-gray-300" : "text-gray-700"}`}>
                {t.username}
              </label>
              <div className="relative group">
                <UserIcon
                  className={`absolute left-4 top-1/2 -translate-y-1/2 transition-all ${
                    isDark
                      ? "text-gray-400 group-focus-within:text-cyan-400"
                      : "text-gray-500 group-focus-within:text-blue-500"
                  }`}
                  size={20}
                />
                <input
                  type="text"
                  value={username}
                  onChange={(e) => handleInputChange(setUsername, e.target.value.toLowerCase())}
                  className={`w-full pl-12 pr-4 py-3.5 rounded-xl border-2 transition-all font-medium text-base
                    ${
                      isDark
                        ? "bg-gray-800/50 border-gray-700 text-white focus:border-cyan-500 focus:bg-gray-800"
                        : "bg-white border-gray-300 text-gray-900 focus:border-blue-500"
                    }
                    focus:outline-none focus:ring-2 ${isDark ? "focus:ring-cyan-500/20" : "focus:ring-blue-500/20"}
                  `}
                  placeholder={t.username}
                  disabled={isLoading}
                  autoComplete="new-username"
                />
              </div>
              <p className={`text-xs mt-1 text-center ${isDark ? "text-gray-400" : "text-gray-600"}`}>
                {t.usernameFormat}
              </p>
            </div>

            <div>
              <label className={`block text-sm font-semibold mb-2 ${isDark ? "text-gray-300" : "text-gray-700"}`}>
                {t.email}
              </label>
              <div className="relative group">
                <Mail
                  className={`absolute left-4 top-1/2 -translate-y-1/2 transition-all ${
                    isDark
                      ? "text-gray-400 group-focus-within:text-cyan-400"
                      : "text-gray-500 group-focus-within:text-blue-500"
                  }`}
                  size={20}
                />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => handleInputChange(setEmail, e.target.value)}
                  className={`w-full pl-12 pr-4 py-3.5 rounded-xl border-2 transition-all font-medium text-base
                    ${
                      isDark
                        ? "bg-gray-800/50 border-gray-700 text-white focus:border-cyan-500 focus:bg-gray-800"
                        : "bg-white border-gray-300 text-gray-900 focus:border-blue-500"
                    }
                    focus:outline-none focus:ring-2 ${isDark ? "focus:ring-cyan-500/20" : "focus:ring-blue-500/20"}
                  `}
                  placeholder={t.email}
                  disabled={isLoading}
                  autoComplete="new-email"
                />
              </div>
            </div>

            <div>
              <label className={`block text-sm font-semibold mb-2 ${isDark ? "text-gray-300" : "text-gray-700"}`}>
                {t.name}
              </label>
              <div className="relative group">
                <UserIcon
                  className={`absolute left-4 top-1/2 -translate-y-1/2 transition-all ${
                    isDark
                      ? "text-gray-400 group-focus-within:text-cyan-400"
                      : "text-gray-500 group-focus-within:text-blue-500"
                  }`}
                  size={20}
                />
                <input
                  type="text"
                  value={name}
                  onChange={(e) => handleInputChange(setName, e.target.value)}
                  className={`w-full pl-12 pr-4 py-3.5 rounded-xl border-2 transition-all font-medium text-base
                    ${
                      isDark
                        ? "bg-gray-800/50 border-gray-700 text-white focus:border-cyan-500 focus:bg-gray-800"
                        : "bg-white border-gray-300 text-gray-900 focus:border-blue-500"
                    }
                    focus:outline-none focus:ring-2 ${isDark ? "focus:ring-cyan-500/20" : "focus:ring-blue-500/20"}
                  `}
                  placeholder={t.name}
                  disabled={isLoading}
                />
              </div>
            </div>

            <div>
              <label className={`block text-sm font-semibold mb-2 ${isDark ? "text-gray-300" : "text-gray-700"}`}>
                {t.password}
              </label>
              <div className="relative group">
                <Lock
                  className={`absolute left-4 top-1/2 -translate-y-1/2 transition-all ${
                    isDark
                      ? "text-gray-400 group-focus-within:text-cyan-400"
                      : "text-gray-500 group-focus-within:text-blue-500"
                  }`}
                  size={20}
                />
                <input
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => handleInputChange(setPassword, e.target.value)}
                  className={`w-full pl-12 pr-12 py-3.5 rounded-xl border-2 transition-all font-medium text-base
                    ${
                      isDark
                        ? "bg-gray-800/50 border-gray-700 text-white focus:border-cyan-500 focus:bg-gray-800"
                        : "bg-white border-gray-300 text-gray-900 focus:border-blue-500"
                    }
                    focus:outline-none focus:ring-2 ${isDark ? "focus:ring-cyan-500/20" : "focus:ring-blue-500/20"}
                  `}
                  placeholder={t.password}
                  disabled={isLoading}
                  autoComplete="new-password"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className={`absolute right-4 top-1/2 -translate-y-1/2 transition-colors ${
                    isDark ? "text-gray-400 hover:text-cyan-400" : "text-gray-500 hover:text-blue-500"
                  }`}
                  disabled={isLoading}
                >
                  {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
                </button>
              </div>
              <p className={`text-xs mt-1 text-center ${isDark ? "text-gray-400" : "text-gray-600"}`}>
                {t.passwordMin}
              </p>
            </div>

            <div>
              <label className={`block text-sm font-semibold mb-2 ${isDark ? "text-gray-300" : "text-gray-700"}`}>
                Confirm Password
              </label>
              <div className="relative group">
                <Lock
                  className={`absolute left-4 top-1/2 -translate-y-1/2 transition-all ${
                    isDark
                      ? "text-gray-400 group-focus-within:text-cyan-400"
                      : "text-gray-500 group-focus-within:text-blue-500"
                  }`}
                  size={20}
                />
                <input
                  type={showPassword ? "text" : "password"}
                  value={confirmPassword}
                  onChange={(e) => handleInputChange(setConfirmPassword, e.target.value)}
                  className={`w-full pl-12 pr-12 py-3.5 rounded-xl border-2 transition-all font-medium text-base
                    ${
                      isDark
                        ? "bg-gray-800/50 border-gray-700 text-white focus:border-cyan-500 focus:bg-gray-800"
                        : "bg-white border-gray-300 text-gray-900 focus:border-blue-500"
                    }
                    focus:outline-none focus:ring-2 ${isDark ? "focus:ring-cyan-500/20" : "focus:ring-blue-500/20"}
                  `}
                  placeholder="••••••••"
                  disabled={isLoading}
                  autoComplete="new-password"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className={`absolute right-4 top-1/2 -translate-y-1/2 transition-colors ${
                    isDark ? "text-gray-400 hover:text-cyan-400" : "text-gray-500 hover:text-blue-500"
                  }`}
                  disabled={isLoading}
                >
                  {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
                </button>
              </div>
              <p className={`text-xs mt-1 text-center ${isDark ? "text-gray-400" : "text-gray-600"}`}>
                {t.passwordMin}
              </p>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className={`w-full py-3.5 rounded-xl font-bold text-base transition-all transform hover:scale-[1.02] active:scale-[0.98]
                ${
                  isDark
                    ? "bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-600 hover:to-blue-600 text-white"
                    : "bg-gradient-to-r from-blue-500 to-indigo-500 hover:from-blue-600 hover:to-indigo-600 text-white"
                }
                disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none
                ${neonGlow}
              `}
            >
              {isLoading ? (
                <span className="flex items-center justify-center gap-2">
                  <Loader2 className="animate-spin" size={20} />
                  {t.loading}
                </span>
              ) : (
                t.registerButton
              )}
            </button>

            <p className={`text-center text-sm ${isDark ? "text-gray-400" : "text-gray-600"}`}>
              {t.alreadyHaveAccount}{" "}
              <button
                type="button"
                onClick={() => setMode("login")}
                className={`font-semibold ${isDark ? "text-cyan-400 hover:text-cyan-300" : "text-blue-600 hover:text-blue-700"}`}
              >
                {t.loginHere}
              </button>
            </p>
          </form>
        )}
      </div>
    </div>
  )
}

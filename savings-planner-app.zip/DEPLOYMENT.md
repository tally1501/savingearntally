# Deployment Guide - Cross-Device Authentication System

This guide covers deploying your authentication system to enable true cross-device login.

## Quick Start (Easiest Method)

### Option 1: Vercel + Supabase (Recommended for beginners)

1. **Setup Supabase Database**
   - Go to https://supabase.com and create a free account
   - Create a new project
   - Go to SQL Editor and run the contents of `backend-api/database-setup.sql`
   - Copy your database connection string from Settings > Database

2. **Deploy to Vercel**
   - Push your code to GitHub
   - Go to https://vercel.com and import your repository
   - Add environment variables:
     ```
     DATABASE_URL=your_supabase_connection_string
     JWT_SECRET=your_random_secret_key_here
     ```
   - Deploy

3. **Update Frontend**
   - Replace localStorage calls in `lib/auth-service.ts` with API fetch calls
   - Update the API endpoints to point to your Vercel deployment

### Option 2: Railway (Backend + Database together)

1. **Setup Railway**
   - Go to https://railway.app and create account
   - Click "New Project" > "Deploy PostgreSQL"
   - Copy the database connection string

2. **Deploy Backend**
   - Create a new service for your backend API
   - Connect your GitHub repository
   - Add environment variables:
     ```
     DATABASE_URL=your_railway_postgres_url
     JWT_SECRET=your_random_secret_key
     PORT=3001
     ```
   - Deploy

3. **Deploy Frontend to Vercel**
   - Same as Option 1 above
   - Update API endpoint URLs to point to your Railway backend

## Detailed Setup

### 1. Database Setup

Choose one:
- **Supabase** (Easiest) - https://supabase.com
- **Railway PostgreSQL** - https://railway.app
- **Neon** - https://neon.tech
- **AWS RDS** (Advanced) - https://aws.amazon.com/rds/

Run `backend-api/database-setup.sql` in your database.

### 2. Backend Deployment

Choose one:
- **Next.js API Routes** (Easiest - no separate backend)
- **Express.js on Railway/Render**
- **AWS Lambda** (Serverless)

Install dependencies:
```bash
npm install bcrypt jsonwebtoken pg
npm install --save-dev @types/bcrypt @types/jsonwebtoken
```

### 3. Frontend Updates

Update `lib/auth-service.ts` to use your API:

```typescript
// Replace localStorage with API calls
export async function registerUser(data) {
  const response = await fetch('https://your-api.com/api/register', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
  })
  return response.json()
}

export async function loginUser(identifier, password) {
  const response = await fetch('https://your-api.com/api/login', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ identifier, password })
  })
  return response.json()
}
```

### 4. Environment Variables

Create `.env.local` for frontend:
```
NEXT_PUBLIC_API_URL=https://your-api-url.com
```

Create `.env` for backend:
```
DATABASE_URL=postgresql://user:pass@host:5432/db
JWT_SECRET=your-super-secret-jwt-key
JWT_EXPIRES_IN=30d
ALLOWED_ORIGINS=https://your-frontend.vercel.app
PORT=3001
```

### 5. Testing Cross-Device Login

1. Deploy your app
2. Register an account on your phone
3. Try logging in on your PC with the same credentials
4. Should work seamlessly!

## Security Checklist

- [ ] Use HTTPS in production
- [ ] Set strong JWT_SECRET (use `openssl rand -base64 32`)
- [ ] Enable CORS only for your frontend domain
- [ ] Add rate limiting to prevent brute force attacks
- [ ] Validate all input on backend
- [ ] Use prepared statements to prevent SQL injection
- [ ] Store JWT in httpOnly cookies (more secure than localStorage)
- [ ] Implement token refresh mechanism
- [ ] Add password reset functionality
- [ ] Log authentication attempts for security monitoring

## Cost Estimates

### Free Tier (Good for starting):
- **Vercel**: Free for personal projects
- **Supabase**: 500MB database, 50,000 monthly active users free
- **Total**: $0/month

### Production (Recommended):
- **Vercel Pro**: $20/month
- **Supabase Pro**: $25/month (1TB bandwidth, 8GB database)
- **Total**: $45/month

## Troubleshooting

### JWT Token Issues
- Make sure JWT_SECRET is the same on all backend instances
- Check token expiration time
- Verify Authorization header format: `Bearer <token>`

### CORS Errors
- Add CORS middleware to backend
- Set correct ALLOWED_ORIGINS
- Check browser console for specific CORS error

### Database Connection Errors
- Verify DATABASE_URL format
- Check firewall rules allow connections
- Ensure SSL is enabled if required

## Support

For issues or questions:
1. Check the backend API logs
2. Review the frontend network tab in browser dev tools
3. Verify environment variables are set correctly
4. Check database connection and query logs

# Firebase Authentication Setup Guide

This app now uses Firebase Authentication for cross-device login. Follow these steps to activate it:

## Step 1: Create Firebase Project

1. Go to [Firebase Console](https://console.firebase.google.com/)
2. Click "Add project"
3. Enter project name (e.g., "saving-earn-app")
4. Disable Google Analytics (optional for this project)
5. Click "Create project"

## Step 2: Enable Authentication Methods

1. In Firebase Console, go to **Build > Authentication**
2. Click "Get started"
3. Enable the following sign-in methods:
   - **Email/Password**: Toggle ON
   - **Google**: Toggle ON (optional, for Google OAuth)

## Step 3: Create Firestore Database

1. Go to **Build > Firestore Database**
2. Click "Create database"
3. Select **Start in production mode** or **Test mode** (test mode for development)
4. Choose a location closest to your users
5. Click "Enable"

## Step 4: Set Up Firebase Storage

1. Go to **Build > Storage**
2. Click "Get started"
3. Accept the default security rules
4. Choose the same location as Firestore
5. Click "Done"

## Step 5: Get Firebase Configuration

1. Go to **Project Settings** (gear icon)
2. Scroll down to "Your apps"
3. Click the **Web icon** (</>)
4. Register app with a nickname (e.g., "Savings App Web")
5. Copy the `firebaseConfig` object values

## Step 6: Configure Environment Variables

1. Create a file named `.env.local` in your project root
2. Copy the contents from `.env.local.example`
3. Replace the placeholder values with your Firebase config:

```env
NEXT_PUBLIC_FIREBASE_API_KEY=AIza...
NEXT_PUBLIC_FIREBASE_AUTH_DOMAIN=your-project.firebaseapp.com
NEXT_PUBLIC_FIREBASE_PROJECT_ID=your-project-id
NEXT_PUBLIC_FIREBASE_STORAGE_BUCKET=your-project.appspot.com
NEXT_PUBLIC_FIREBASE_MESSAGING_SENDER_ID=123456789
NEXT_PUBLIC_FIREBASE_APP_ID=1:123456789:web:abc123
```

## Step 7: Install Dependencies

Run the following command to install Firebase:

```bash
npm install firebase
```

The Firebase SDK is already added to `package.json`.

## Step 8: Deploy Firestore Security Rules (Important!)

1. In Firebase Console, go to **Firestore Database > Rules**
2. Replace the default rules with:

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    // Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
  apiKey: "AIzaSyApsOu86gC2fnfVh07jsTa9--bX9HljMAU",
  authDomain: "savingearn-4fb93.firebaseapp.com",
  projectId: "savingearn-4fb93",
  storageBucket: "savingearn-4fb93.firebasestorage.app",
  messagingSenderId: "408225099356",
  appId: "1:408225099356:web:a684286ea60fce6677c099",
  measurementId: "G-BC1WPJ5BSV"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);
    }
  }
}
```

3. Click "Publish"

## Step 9: Deploy Storage Security Rules

1. Go to **Storage > Rules**
2. Replace with:

```javascript
rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {
    match /profile-photos/{userId} {
      allow read: if request.auth != null;
      allow write: if request.auth.uid == userId && request.resource.size < 5 * 1024 * 1024;
    }
  }
}
```

3. Click "Publish"

## Step 10: Test Cross-Device Login

1. Start your development server: `npm run dev`
2. Register a new account on Device A (e.g., your phone)
3. Open the app on Device B (e.g., your laptop)
4. Login with the same username/email and password
5. Your account should work on both devices!

## How It Works

- **Firebase Authentication**: Manages user accounts centrally in the cloud
- **Firestore Database**: Stores username, profile data, and settings
- **Firebase Storage**: Stores profile photos in the cloud
- **Cross-Device**: Login once, access from any device with same credentials

## Troubleshooting

**Issue**: "Firebase: Error (auth/unauthorized-domain)"
- **Solution**: Go to Firebase Console > Authentication > Settings > Authorized domains
- Add your deployment domain (e.g., `your-app.vercel.app`)

**Issue**: "Insufficient permissions"
- **Solution**: Check Firestore and Storage security rules are properly deployed

**Issue**: Login works but no data syncs
- **Solution**: Verify Firestore database is created and rules are set

## Support

For Firebase documentation, visit:
- [Firebase Auth Docs](https://firebase.google.com/docs/auth)
- [Firestore Docs](https://firebase.google.com/docs/firestore)
- [Storage Docs](https://firebase.google.com/docs/storage)

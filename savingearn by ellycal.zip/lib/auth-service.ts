// Authentication service for handling user authentication
// Includes OTP generation, email validation, and token management

export interface User {
  id: string
  email?: string
  phone?: string
  name?: string
  token: string
  createdAt: string
}

export interface OTPSession {
  phone: string
  otp: string
  expiresAt: number
  attempts: number
}

// Encrypt password using SHA-256
export async function hashPassword(password: string): Promise<string> {
  const encoder = new TextEncoder()
  const data = encoder.encode(password)
  const hashBuffer = await crypto.subtle.digest("SHA-256", data)
  const hashArray = Array.from(new Uint8Array(hashBuffer))
  return hashArray.map((b) => b.toString(16).padStart(2, "0")).join("")
}

// Generate 6-digit OTP
export function generateOTP(): string {
  return Math.floor(100000 + Math.random() * 900000).toString()
}

// Generate secure auth token
export function generateToken(identifier: string): string {
  return btoa(`${identifier}:${Date.now()}:${Math.random()}`)
}

// Validate email format
export function validateEmail(email: string): boolean {
  const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
  return re.test(email)
}

// Validate phone number (Indonesian format)
export function validatePhone(phone: string): boolean {
  const re = /^(\+62|62|0)[0-9]{9,12}$/
  return re.test(phone)
}

// Store OTP session (expires in 5 minutes)
export function storeOTPSession(phone: string, otp: string): void {
  const session: OTPSession = {
    phone,
    otp,
    expiresAt: Date.now() + 5 * 60 * 1000, // 5 minutes
    attempts: 0,
  }
  localStorage.setItem(`otp_${phone}`, JSON.stringify(session))
}

// Verify OTP
export function verifyOTP(phone: string, otp: string): boolean {
  const sessionData = localStorage.getItem(`otp_${phone}`)
  if (!sessionData) return false

  const session: OTPSession = JSON.parse(sessionData)

  // Check expiry
  if (Date.now() > session.expiresAt) {
    localStorage.removeItem(`otp_${phone}`)
    return false
  }

  // Check attempts (max 3)
  if (session.attempts >= 3) {
    localStorage.removeItem(`otp_${phone}`)
    return false
  }

  // Verify OTP
  if (session.otp === otp) {
    localStorage.removeItem(`otp_${phone}`)
    return true
  }

  // Increment attempts
  session.attempts++
  localStorage.setItem(`otp_${phone}`, JSON.stringify(session))
  return false
}

// Send OTP (simulated - in production, use SMS API like Twilio)
export async function sendOTP(phone: string): Promise<{ success: boolean; message: string }> {
  const otp = generateOTP()

  // Simulate API delay
  await new Promise((resolve) => setTimeout(resolve, 1000))

  // Store OTP session
  storeOTPSession(phone, otp)

  // In production, send via SMS API
  console.log(`[OTP] Kode OTP untuk ${phone}: ${otp}`)

  return {
    success: true,
    message: `Kode OTP telah dikirim ke ${phone}. (Cek console untuk demo)`,
  }
}

// Register user
export async function registerUser(data: {
  email?: string
  phone?: string
  password: string
  name?: string
}): Promise<{ success: boolean; user?: User; error?: string }> {
  try {
    // Hash password
    const hashedPassword = await hashPassword(data.password)

    // Create user object
    const user: User = {
      id: `user_${Date.now()}`,
      email: data.email,
      phone: data.phone,
      name: data.name,
      token: generateToken(data.email || data.phone || ""),
      createdAt: new Date().toISOString(),
    }

    // Store user data (in production, this would be in a database)
    const users = JSON.parse(localStorage.getItem("users") || "[]")
    users.push({ ...user, password: hashedPassword })
    localStorage.setItem("users", JSON.stringify(users))

    // Store auth session
    localStorage.setItem("user", JSON.stringify(user))
    localStorage.setItem("authToken", user.token)

    return { success: true, user }
  } catch (error) {
    return { success: false, error: "Gagal mendaftar" }
  }
}

// Login user
export async function loginUser(
  identifier: string,
  password: string,
): Promise<{ success: boolean; user?: User; error?: string }> {
  try {
    // Hash password
    const hashedPassword = await hashPassword(password)

    // Get users (in production, this would be an API call)
    const users = JSON.parse(localStorage.getItem("users") || "[]")

    // Find user
    const userData = users.find(
      (u: any) => (u.email === identifier || u.phone === identifier) && u.password === hashedPassword,
    )

    if (!userData) {
      return { success: false, error: "Email/No HP atau password salah" }
    }

    // Create user session
    const user: User = {
      id: userData.id,
      email: userData.email,
      phone: userData.phone,
      name: userData.name,
      token: generateToken(identifier),
      createdAt: userData.createdAt,
    }

    // Store auth session
    localStorage.setItem("user", JSON.stringify(user))
    localStorage.setItem("authToken", user.token)

    return { success: true, user }
  } catch (error) {
    return { success: false, error: "Terjadi kesalahan" }
  }
}

// Google OAuth simulation (in production, use NextAuth.js or similar)
export async function loginWithGoogle(): Promise<{ success: boolean; user?: User; error?: string }> {
  // Simulate OAuth flow
  await new Promise((resolve) => setTimeout(resolve, 1500))

  // In production, this would redirect to Google OAuth
  const mockUser: User = {
    id: `google_${Date.now()}`,
    email: "user@gmail.com",
    name: "Google User",
    token: generateToken("user@gmail.com"),
    createdAt: new Date().toISOString(),
  }

  localStorage.setItem("user", JSON.stringify(mockUser))
  localStorage.setItem("authToken", mockUser.token)

  return { success: true, user: mockUser }
}

// Logout user
export function logoutUser(): void {
  localStorage.removeItem("user")
  localStorage.removeItem("authToken")
}

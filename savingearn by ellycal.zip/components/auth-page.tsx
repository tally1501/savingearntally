"use client"

import type React from "react"

import { useState } from "react"
import Image from "next/image"
import { Eye, EyeOff, Mail, Phone, Lock, UserIcon, Globe } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import {
  validateEmail,
  validatePhone,
  sendOTP,
  verifyOTP,
  registerUser,
  loginUser,
  loginWithGoogle,
  type User,
} from "@/lib/auth-service"

type AuthMode = "login" | "register" | "otp"
type RegisterMethod = "phone" | "email"
type Language = "id" | "en"

interface AuthPageProps {
  onLogin: (user: User) => void
  isDark: boolean
  lang: Language
  setLang: (lang: Language) => void
  setIsDark: (isDark: boolean) => void
}

const translations = {
  id: {
    welcome: "Selamat Datang",
    login: "Masuk",
    register: "Daftar",
    email: "Email/Username",
    phone: "Nomor HP",
    password: "Password",
    name: "Nama Lengkap",
    loginButton: "Masuk",
    registerButton: "Daftar Akun",
    loginWithGoogle: "Masuk dengan Google",
    registerWithPhone: "Daftar dengan No HP",
    registerWithEmail: "Daftar dengan Email",
    sendOTP: "Kirim Kode OTP",
    verifyOTP: "Verifikasi OTP",
    otpCode: "Kode OTP",
    otpSent: "Kode OTP telah dikirim",
    dontHaveAccount: "Belum punya akun?",
    alreadyHaveAccount: "Sudah punya akun?",
    registerHere: "Daftar di sini",
    loginHere: "Masuk di sini",
    passwordMin: "Minimal 8 karakter",
    phoneFormat: "Format: 08xx atau +62xxx",
    emailRequired: "Email harus diisi",
    phoneRequired: "Nomor HP harus diisi",
    passwordRequired: "Password minimal 8 karakter",
    nameRequired: "Nama harus diisi",
    invalidEmail: "Format email tidak valid",
    invalidPhone: "Format nomor HP tidak valid",
    otpInvalid: "Kode OTP salah atau kadaluarsa",
    loginSuccess: "Berhasil masuk!",
    registerSuccess: "Berhasil mendaftar!",
  },
  en: {
    welcome: "Welcome",
    login: "Login",
    register: "Sign Up",
    email: "Email/Username",
    phone: "Phone Number",
    password: "Password",
    name: "Full Name",
    loginButton: "Sign In",
    registerButton: "Create Account",
    loginWithGoogle: "Sign in with Google",
    registerWithPhone: "Sign up with Phone",
    registerWithEmail: "Sign up with Email",
    sendOTP: "Send OTP Code",
    verifyOTP: "Verify OTP",
    otpCode: "OTP Code",
    otpSent: "OTP code has been sent",
    dontHaveAccount: "Don't have an account?",
    alreadyHaveAccount: "Already have an account?",
    registerHere: "Sign up here",
    loginHere: "Sign in here",
    passwordMin: "Minimum 8 characters",
    phoneFormat: "Format: 08xx or +62xxx",
    emailRequired: "Email is required",
    phoneRequired: "Phone number is required",
    passwordRequired: "Password minimum 8 characters",
    nameRequired: "Name is required",
    invalidEmail: "Invalid email format",
    invalidPhone: "Invalid phone number format",
    otpInvalid: "OTP code is incorrect or expired",
    loginSuccess: "Successfully logged in!",
    registerSuccess: "Successfully registered!",
  },
}

export function AuthPage({ onLogin, isDark, lang, setLang, setIsDark }: AuthPageProps) {
  const t = translations[lang]

  const [mode, setMode] = useState<AuthMode>("login")
  const [registerMethod, setRegisterMethod] = useState<RegisterMethod>("phone")

  // Login state
  const [loginIdentifier, setLoginIdentifier] = useState("")
  const [loginPassword, setLoginPassword] = useState("")

  // Register state
  const [registerName, setRegisterName] = useState("")
  const [registerEmail, setRegisterEmail] = useState("")
  const [registerPhone, setRegisterPhone] = useState("")
  const [registerPassword, setRegisterPassword] = useState("")

  // OTP state
  const [otpCode, setOtpCode] = useState("")
  const [otpSent, setOtpSent] = useState(false)

  // UI state
  const [showPassword, setShowPassword] = useState(false)
  const [error, setError] = useState("")
  const [success, setSuccess] = useState("")
  const [isLoading, setIsLoading] = useState(false)

  const neonGlow = isDark ? "shadow-[0_0_20px_rgba(0,212,255,0.6)]" : "shadow-[0_0_15px_rgba(0,149,255,0.4)]"

  // Handle login
  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setSuccess("")

    if (!loginIdentifier) {
      setError(t.emailRequired)
      return
    }

    if (loginPassword.length < 8) {
      setError(t.passwordRequired)
      return
    }

    setIsLoading(true)

    const result = await loginUser(loginIdentifier, loginPassword)

    setIsLoading(false)

    if (result.success && result.user) {
      setSuccess(t.loginSuccess)
      setTimeout(() => onLogin(result.user!), 500)
    } else {
      setError(result.error || "Login gagal")
    }
  }

  // Handle send OTP
  const handleSendOTP = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setSuccess("")

    if (!validatePhone(registerPhone)) {
      setError(t.invalidPhone)
      return
    }

    setIsLoading(true)

    const result = await sendOTP(registerPhone)

    setIsLoading(false)

    if (result.success) {
      setOtpSent(true)
      setSuccess(result.message)
      setMode("otp")
    } else {
      setError(result.message)
    }
  }

  // Handle verify OTP and register
  const handleVerifyOTP = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setSuccess("")

    if (otpCode.length !== 6) {
      setError("Kode OTP harus 6 digit")
      return
    }

    if (!registerName) {
      setError(t.nameRequired)
      return
    }

    if (registerPassword.length < 8) {
      setError(t.passwordRequired)
      return
    }

    setIsLoading(true)

    // Verify OTP
    const isValid = verifyOTP(registerPhone, otpCode)

    if (!isValid) {
      setIsLoading(false)
      setError(t.otpInvalid)
      return
    }

    // Register user
    const result = await registerUser({
      phone: registerPhone,
      password: registerPassword,
      name: registerName,
    })

    setIsLoading(false)

    if (result.success && result.user) {
      setSuccess(t.registerSuccess)
      setTimeout(() => onLogin(result.user!), 500)
    } else {
      setError(result.error || "Pendaftaran gagal")
    }
  }

  // Handle register with email
  const handleRegisterWithEmail = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setSuccess("")

    if (!validateEmail(registerEmail)) {
      setError(t.invalidEmail)
      return
    }

    if (!registerName) {
      setError(t.nameRequired)
      return
    }

    if (registerPassword.length < 8) {
      setError(t.passwordRequired)
      return
    }

    setIsLoading(true)

    const result = await registerUser({
      email: registerEmail,
      password: registerPassword,
      name: registerName,
    })

    setIsLoading(false)

    if (result.success && result.user) {
      setSuccess(t.registerSuccess)
      setTimeout(() => onLogin(result.user!), 500)
    } else {
      setError(result.error || "Pendaftaran gagal")
    }
  }

  // Handle Google login
  const handleGoogleLogin = async () => {
    setError("")
    setSuccess("")
    setIsLoading(true)

    const result = await loginWithGoogle()

    setIsLoading(false)

    if (result.success && result.user) {
      setSuccess(t.loginSuccess)
      setTimeout(() => onLogin(result.user!), 500)
    } else {
      setError(result.error || "Login dengan Google gagal")
    }
  }

  return (
    <div
      className={`min-h-screen flex items-center justify-center transition-colors duration-500 ${
        isDark
          ? "bg-gradient-to-br from-[#0a0e27] via-[#1a1a2e] to-[#16213e]"
          : "bg-gradient-to-br from-blue-50 via-white to-cyan-50"
      }`}
    >
      {/* Language and Theme Toggle */}
      <div className="absolute top-4 right-4 flex items-center gap-3">
        <Button
          variant="ghost"
          size="sm"
          onClick={() => setLang(lang === "id" ? "en" : "id")}
          className={`${isDark ? "text-white hover:bg-white/10" : "text-gray-700 hover:bg-gray-100"}`}
        >
          <Globe className="w-4 h-4 mr-2" />
          {lang === "id" ? "ID" : "EN"}
        </Button>

        <Button
          variant="ghost"
          size="sm"
          onClick={() => setIsDark(!isDark)}
          className={`${isDark ? "text-white hover:bg-white/10" : "text-gray-700 hover:bg-gray-100"}`}
        >
          {isDark ? "☀️" : "🌙"}
        </Button>
      </div>

      {/* Auth Card */}
      <div
        className={`w-full max-w-md mx-4 p-8 rounded-3xl transition-all duration-500 ${
          isDark
            ? "bg-gradient-to-br from-gray-900/90 to-gray-800/90 backdrop-blur-lg border border-cyan-500/30"
            : "bg-white/90 backdrop-blur-lg border border-blue-200 shadow-2xl"
        } ${neonGlow}`}
      >
        {/* Logo */}
        <div className="flex justify-center mb-6">
          <Image
            src="/images/api-attachments-bx4bhnk5pzjvdxoq0v9or.png"
            alt="Saving Earn Logo"
            width={120}
            height={120}
            className="rounded-2xl"
          />
        </div>

        {/* Title */}
        <h1 className={`text-3xl font-bold text-center mb-2 ${isDark ? "text-white" : "text-gray-900"}`}>
          {mode === "login" ? t.welcome : mode === "otp" ? t.verifyOTP : t.register}
        </h1>
        <p className={`text-center mb-8 ${isDark ? "text-gray-400" : "text-gray-600"}`}>Saving Earn By Ellycal</p>

        {/* Error/Success Messages */}
        {error && (
          <div className="mb-4 p-3 rounded-lg bg-red-500/20 border border-red-500/50 text-red-500 text-sm">{error}</div>
        )}
        {success && (
          <div className="mb-4 p-3 rounded-lg bg-green-500/20 border border-green-500/50 text-green-500 text-sm">
            {success}
          </div>
        )}

        {/* Login Form */}
        {mode === "login" && (
          <form onSubmit={handleLogin} className="space-y-5">
            <div>
              <Label className={isDark ? "text-gray-300" : "text-gray-700"}>{t.email}</Label>
              <div className="relative mt-2">
                <Mail
                  className={`absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 ${
                    isDark ? "text-gray-400" : "text-gray-500"
                  }`}
                />
                <Input
                  type="text"
                  value={loginIdentifier}
                  onChange={(e) => setLoginIdentifier(e.target.value)}
                  className={`pl-11 h-12 rounded-xl ${
                    isDark
                      ? "bg-gray-800/50 border-gray-700 text-white placeholder:text-gray-500"
                      : "bg-white border-gray-300"
                  }`}
                  placeholder="email@example.com"
                />
              </div>
            </div>

            <div>
              <Label className={isDark ? "text-gray-300" : "text-gray-700"}>{t.password}</Label>
              <div className="relative mt-2">
                <Lock
                  className={`absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 ${
                    isDark ? "text-gray-400" : "text-gray-500"
                  }`}
                />
                <Input
                  type={showPassword ? "text" : "password"}
                  value={loginPassword}
                  onChange={(e) => setLoginPassword(e.target.value)}
                  className={`pl-11 pr-11 h-12 rounded-xl ${
                    isDark
                      ? "bg-gray-800/50 border-gray-700 text-white placeholder:text-gray-500"
                      : "bg-white border-gray-300"
                  }`}
                  placeholder="••••••••"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2"
                >
                  {showPassword ? (
                    <EyeOff className={`w-5 h-5 ${isDark ? "text-gray-400" : "text-gray-500"}`} />
                  ) : (
                    <Eye className={`w-5 h-5 ${isDark ? "text-gray-400" : "text-gray-500"}`} />
                  )}
                </button>
              </div>
              <p className={`text-xs mt-1 ${isDark ? "text-gray-500" : "text-gray-600"}`}>{t.passwordMin}</p>
            </div>

            <Button
              type="submit"
              disabled={isLoading}
              className={`w-full h-12 rounded-xl font-semibold transition-all ${
                isDark
                  ? "bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700"
                  : "bg-gradient-to-r from-blue-500 to-cyan-600 hover:from-blue-600 hover:to-cyan-700"
              } ${neonGlow}`}
            >
              {isLoading ? (
                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                t.loginButton
              )}
            </Button>

            <div className="relative my-6">
              <div className={`absolute inset-0 flex items-center`}>
                <div className={`w-full border-t ${isDark ? "border-gray-700" : "border-gray-300"}`} />
              </div>
              <div className="relative flex justify-center text-sm">
                <span className={`px-2 ${isDark ? "bg-gray-900 text-gray-400" : "bg-white text-gray-600"}`}>atau</span>
              </div>
            </div>

            <Button
              type="button"
              onClick={handleGoogleLogin}
              disabled={isLoading}
              variant="outline"
              className={`w-full h-12 rounded-xl font-semibold ${
                isDark ? "border-gray-700 hover:bg-gray-800 text-white" : "border-gray-300 hover:bg-gray-50"
              }`}
            >
              <svg className="w-5 h-5 mr-2" viewBox="0 0 24 24">
                <path
                  fill="currentColor"
                  d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"
                />
                <path
                  fill="currentColor"
                  d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"
                />
                <path
                  fill="currentColor"
                  d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"
                />
                <path
                  fill="currentColor"
                  d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"
                />
              </svg>
              {t.loginWithGoogle}
            </Button>

            <p className={`text-center text-sm ${isDark ? "text-gray-400" : "text-gray-600"}`}>
              {t.dontHaveAccount}{" "}
              <button
                type="button"
                onClick={() => setMode("register")}
                className={`font-semibold ${isDark ? "text-cyan-400 hover:text-cyan-300" : "text-blue-600 hover:text-blue-700"}`}
              >
                {t.registerHere}
              </button>
            </p>
          </form>
        )}

        {/* Register Method Selection */}
        {mode === "register" && !otpSent && (
          <div className="space-y-4">
            <Button
              onClick={() => setRegisterMethod("phone")}
              className={`w-full h-14 rounded-xl font-semibold transition-all ${
                registerMethod === "phone"
                  ? isDark
                    ? "bg-gradient-to-r from-cyan-500 to-blue-600"
                    : "bg-gradient-to-r from-blue-500 to-cyan-600"
                  : isDark
                    ? "bg-gray-800 hover:bg-gray-700 text-white"
                    : "bg-gray-100 hover:bg-gray-200 text-gray-900"
              } ${registerMethod === "phone" ? neonGlow : ""}`}
            >
              <Phone className="w-5 h-5 mr-2" />
              {t.registerWithPhone}
            </Button>

            <Button
              onClick={() => setRegisterMethod("email")}
              className={`w-full h-14 rounded-xl font-semibold transition-all ${
                registerMethod === "email"
                  ? isDark
                    ? "bg-gradient-to-r from-cyan-500 to-blue-600"
                    : "bg-gradient-to-r from-blue-500 to-cyan-600"
                  : isDark
                    ? "bg-gray-800 hover:bg-gray-700 text-white"
                    : "bg-gray-100 hover:bg-gray-200 text-gray-900"
              } ${registerMethod === "email" ? neonGlow : ""}`}
            >
              <Mail className="w-5 h-5 mr-2" />
              {t.registerWithEmail}
            </Button>

            {/* Register with Phone */}
            {registerMethod === "phone" && (
              <form onSubmit={handleSendOTP} className="space-y-4 mt-6">
                <div>
                  <Label className={isDark ? "text-gray-300" : "text-gray-700"}>{t.phone}</Label>
                  <div className="relative mt-2">
                    <Phone
                      className={`absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 ${
                        isDark ? "text-gray-400" : "text-gray-500"
                      }`}
                    />
                    <Input
                      type="tel"
                      value={registerPhone}
                      onChange={(e) => setRegisterPhone(e.target.value.replace(/[^0-9+]/g, ""))}
                      className={`pl-11 h-12 rounded-xl ${
                        isDark
                          ? "bg-gray-800/50 border-gray-700 text-white placeholder:text-gray-500"
                          : "bg-white border-gray-300"
                      }`}
                      placeholder="08123456789"
                    />
                  </div>
                  <p className={`text-xs mt-1 ${isDark ? "text-gray-500" : "text-gray-600"}`}>{t.phoneFormat}</p>
                </div>

                <Button
                  type="submit"
                  disabled={isLoading}
                  className={`w-full h-12 rounded-xl font-semibold transition-all ${
                    isDark
                      ? "bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700"
                      : "bg-gradient-to-r from-blue-500 to-cyan-600 hover:from-blue-600 hover:to-cyan-700"
                  } ${neonGlow}`}
                >
                  {isLoading ? (
                    <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  ) : (
                    t.sendOTP
                  )}
                </Button>
              </form>
            )}

            {/* Register with Email */}
            {registerMethod === "email" && (
              <form onSubmit={handleRegisterWithEmail} className="space-y-4 mt-6">
                <div>
                  <Label className={isDark ? "text-gray-300" : "text-gray-700"}>{t.name}</Label>
                  <div className="relative mt-2">
                    <UserIcon
                      className={`absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 ${
                        isDark ? "text-gray-400" : "text-gray-500"
                      }`}
                    />
                    <Input
                      type="text"
                      value={registerName}
                      onChange={(e) => setRegisterName(e.target.value)}
                      className={`pl-11 h-12 rounded-xl ${
                        isDark
                          ? "bg-gray-800/50 border-gray-700 text-white placeholder:text-gray-500"
                          : "bg-white border-gray-300"
                      }`}
                      placeholder="John Doe"
                    />
                  </div>
                </div>

                <div>
                  <Label className={isDark ? "text-gray-300" : "text-gray-700"}>{t.email}</Label>
                  <div className="relative mt-2">
                    <Mail
                      className={`absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 ${
                        isDark ? "text-gray-400" : "text-gray-500"
                      }`}
                    />
                    <Input
                      type="email"
                      value={registerEmail}
                      onChange={(e) => setRegisterEmail(e.target.value)}
                      className={`pl-11 h-12 rounded-xl ${
                        isDark
                          ? "bg-gray-800/50 border-gray-700 text-white placeholder:text-gray-500"
                          : "bg-white border-gray-300"
                      }`}
                      placeholder="email@example.com"
                    />
                  </div>
                </div>

                <div>
                  <Label className={isDark ? "text-gray-300" : "text-gray-700"}>{t.password}</Label>
                  <div className="relative mt-2">
                    <Lock
                      className={`absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 ${
                        isDark ? "text-gray-400" : "text-gray-500"
                      }`}
                    />
                    <Input
                      type={showPassword ? "text" : "password"}
                      value={registerPassword}
                      onChange={(e) => setRegisterPassword(e.target.value)}
                      className={`pl-11 pr-11 h-12 rounded-xl ${
                        isDark
                          ? "bg-gray-800/50 border-gray-700 text-white placeholder:text-gray-500"
                          : "bg-white border-gray-300"
                      }`}
                      placeholder="••••••••"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword(!showPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2"
                    >
                      {showPassword ? (
                        <EyeOff className={`w-5 h-5 ${isDark ? "text-gray-400" : "text-gray-500"}`} />
                      ) : (
                        <Eye className={`w-5 h-5 ${isDark ? "text-gray-400" : "text-gray-500"}`} />
                      )}
                    </button>
                  </div>
                  <p className={`text-xs mt-1 ${isDark ? "text-gray-500" : "text-gray-600"}`}>{t.passwordMin}</p>
                </div>

                <Button
                  type="submit"
                  disabled={isLoading}
                  className={`w-full h-12 rounded-xl font-semibold transition-all ${
                    isDark
                      ? "bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700"
                      : "bg-gradient-to-r from-blue-500 to-cyan-600 hover:from-blue-600 hover:to-cyan-700"
                  } ${neonGlow}`}
                >
                  {isLoading ? (
                    <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  ) : (
                    t.registerButton
                  )}
                </Button>
              </form>
            )}

            <p className={`text-center text-sm mt-6 ${isDark ? "text-gray-400" : "text-gray-600"}`}>
              {t.alreadyHaveAccount}{" "}
              <button
                type="button"
                onClick={() => {
                  setMode("login")
                  setOtpSent(false)
                }}
                className={`font-semibold ${isDark ? "text-cyan-400 hover:text-cyan-300" : "text-blue-600 hover:text-blue-700"}`}
              >
                {t.loginHere}
              </button>
            </p>
          </div>
        )}

        {/* OTP Verification Form */}
        {mode === "otp" && (
          <form onSubmit={handleVerifyOTP} className="space-y-5">
            <div>
              <Label className={isDark ? "text-gray-300" : "text-gray-700"}>{t.name}</Label>
              <div className="relative mt-2">
                <UserIcon
                  className={`absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 ${
                    isDark ? "text-gray-400" : "text-gray-500"
                  }`}
                />
                <Input
                  type="text"
                  value={registerName}
                  onChange={(e) => setRegisterName(e.target.value)}
                  className={`pl-11 h-12 rounded-xl ${
                    isDark
                      ? "bg-gray-800/50 border-gray-700 text-white placeholder:text-gray-500"
                      : "bg-white border-gray-300"
                  }`}
                  placeholder="John Doe"
                />
              </div>
            </div>

            <div>
              <Label className={isDark ? "text-gray-300" : "text-gray-700"}>{t.password}</Label>
              <div className="relative mt-2">
                <Lock
                  className={`absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 ${
                    isDark ? "text-gray-400" : "text-gray-500"
                  }`}
                />
                <Input
                  type={showPassword ? "text" : "password"}
                  value={registerPassword}
                  onChange={(e) => setRegisterPassword(e.target.value)}
                  className={`pl-11 pr-11 h-12 rounded-xl ${
                    isDark
                      ? "bg-gray-800/50 border-gray-700 text-white placeholder:text-gray-500"
                      : "bg-white border-gray-300"
                  }`}
                  placeholder="••••••••"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2"
                >
                  {showPassword ? (
                    <EyeOff className={`w-5 h-5 ${isDark ? "text-gray-400" : "text-gray-500"}`} />
                  ) : (
                    <Eye className={`w-5 h-5 ${isDark ? "text-gray-400" : "text-gray-500"}`} />
                  )}
                </button>
              </div>
              <p className={`text-xs mt-1 ${isDark ? "text-gray-500" : "text-gray-600"}`}>{t.passwordMin}</p>
            </div>

            <div>
              <Label className={isDark ? "text-gray-300" : "text-gray-700"}>{t.otpCode}</Label>
              <Input
                type="text"
                value={otpCode}
                onChange={(e) => setOtpCode(e.target.value.replace(/[^0-9]/g, "").slice(0, 6))}
                maxLength={6}
                className={`mt-2 h-12 rounded-xl text-center text-2xl tracking-widest ${
                  isDark
                    ? "bg-gray-800/50 border-gray-700 text-white placeholder:text-gray-500"
                    : "bg-white border-gray-300"
                }`}
                placeholder="••••••"
              />
              <p className={`text-xs mt-1 text-center ${isDark ? "text-gray-500" : "text-gray-600"}`}>
                Masukkan 6 digit kode OTP
              </p>
            </div>

            <Button
              type="submit"
              disabled={isLoading}
              className={`w-full h-12 rounded-xl font-semibold transition-all ${
                isDark
                  ? "bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700"
                  : "bg-gradient-to-r from-blue-500 to-cyan-600 hover:from-blue-600 hover:to-cyan-700"
              } ${neonGlow}`}
            >
              {isLoading ? (
                <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
              ) : (
                t.verifyOTP
              )}
            </Button>

            <p className={`text-center text-sm ${isDark ? "text-gray-400" : "text-gray-600"}`}>
              <button
                type="button"
                onClick={() => {
                  setMode("register")
                  setOtpSent(false)
                  setOtpCode("")
                }}
                className={`font-semibold ${isDark ? "text-cyan-400 hover:text-cyan-300" : "text-blue-600 hover:text-blue-700"}`}
              >
                Kirim ulang OTP
              </button>
            </p>
          </form>
        )}
      </div>
    </div>
  )
}

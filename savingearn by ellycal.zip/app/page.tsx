"use client"

import type React from "react"

import { useState, useEffect } from "react"
import {
  Moon,
  Sun,
  Edit2,
  Trash2,
  TrendingUp,
  Wallet,
  Calendar,
  PieChart,
  Plus,
  Lock,
  Mail,
  Eye,
  EyeOff,
  LogOut,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import confetti from "canvas-confetti"
import { AuthPage } from "@/components/auth-page"
import type { User as AuthUser } from "@/lib/auth-service"
import { logoutUser } from "@/lib/auth-service"

// Removed the redeclared 'User' interface, using 'AuthUser' from "@/lib/auth-service" instead.

interface SavingRecord {
  id: string
  month: string
  amount: number
  type: "income" | "expense" | "saving"
}

type Language = "id" | "en"

const translations = {
  id: {
    appName: "Saving Earn By Ellycal",
    login: "Masuk",
    email: "Email / Username",
    password: "Password",
    forgotPassword: "Lupa Password?",
    loginButton: "Masuk",
    loginError: "Email atau password salah",
    emailRequired: "Email harus diisi",
    passwordRequired: "Password minimal 8 karakter",
    invalidEmail: "Format email tidak valid",
    logout: "Keluar",
    loggingIn: "Memproses...",
    // Existing translations
    addTransaction: "Tambah Transaksi",
    editTransaction: "Edit Transaksi",
    monthYear: "Bulan & Tahun",
    monthPlaceholder: "contoh: Januari 2024",
    amount: "Jumlah (Rp)",
    amountPlaceholder: "0",
    type: "Tipe",
    income: "Pemasukan",
    expense: "Pengeluaran",
    saving: "Tabungan",
    save: "Simpan",
    update: "Perbarui",
    targetSavings: "Target Tabungan",
    totalTarget: "Total Target (Rp)",
    duration: "Durasi (bulan)",
    durationPlaceholder: "12",
    setTarget: "Atur Target",
    updateTarget: "Perbarui Target",
    targetAmount: "Target:",
    durationMonths: "Durasi:",
    months: "bulan",
    edit: "Edit",
    delete: "Hapus",
    progress: "Progress",
    currentSavings: "Tabungan Saat Ini",
    target: "Target",
    financialOverview: "Ringkasan Keuangan",
    totalIncome: "Total Pemasukan",
    totalExpense: "Total Pengeluaran",
    totalSaving: "Total Tabungan",
    transactions: "Riwayat Transaksi",
    noTransactions: "Belum ada transaksi",
    startAdding: "Mulai tambahkan pemasukan, pengeluaran, atau tabungan Anda",
    congratulations: "Selamat! Target tercapai! 🎉",
  },
  en: {
    appName: "Saving Earn By Ellycal",
    login: "Login",
    email: "Email / Username",
    password: "Password",
    forgotPassword: "Forgot Password?",
    loginButton: "Login",
    loginError: "Incorrect email or password",
    emailRequired: "Email is required",
    passwordRequired: "Password must be at least 8 characters",
    invalidEmail: "Invalid email format",
    logout: "Logout",
    loggingIn: "Processing...",
    // Existing translations
    addTransaction: "Add Transaction",
    editTransaction: "Edit Transaction",
    monthYear: "Month & Year",
    monthPlaceholder: "e.g., January 2024",
    amount: "Amount (Rp)",
    amountPlaceholder: "0",
    type: "Type",
    income: "Income",
    expense: "Expense",
    saving: "Saving",
    save: "Save",
    update: "Update",
    targetSavings: "Savings Target",
    totalTarget: "Total Target (Rp)",
    duration: "Duration (months)",
    durationPlaceholder: "12",
    setTarget: "Set Target",
    updateTarget: "Update Target",
    targetAmount: "Target:",
    durationMonths: "Duration:",
    months: "months",
    edit: "Edit",
    delete: "Delete",
    progress: "Progress",
    currentSavings: "Current Savings",
    target: "Target",
    financialOverview: "Financial Overview",
    totalIncome: "Total Income",
    totalExpense: "Total Expense",
    totalSaving: "Total Saving",
    transactions: "Transaction History",
    noTransactions: "No transactions yet",
    startAdding: "Start adding your income, expenses, or savings",
    congratulations: "Congratulations! Target achieved! 🎉",
  },
}

function LoginPage({
  onLogin,
  isDark,
  lang,
  setLang,
  setIsDark,
}: {
  onLogin: (user: AuthUser) => void
  isDark: boolean
  lang: Language
  setLang: (lang: Language) => void
  setIsDark: (isDark: boolean) => void
}) {
  const t = translations[lang]
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [showPassword, setShowPassword] = useState(false)
  const [error, setError] = useState("")
  const [isLoading, setIsLoading] = useState(false)

  const validateEmail = (email: string) => {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    return re.test(email) || email.length >= 3 // Allow username or email
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")

    // Validation
    if (!email) {
      setError(t.emailRequired)
      return
    }

    if (password.length < 8) {
      setError(t.passwordRequired)
      return
    }

    // Show loading state
    setIsLoading(true)

    // Simulate API call with timeout
    setTimeout(() => {
      // Simple authentication (in production, this would be a real API call)
      // For demo: accept any email/username with password length >= 8
      const user: AuthUser = {
        email,
        token: btoa(`${email}:${Date.now()}`), // Simple token generation
      }

      // Store encrypted user data
      localStorage.setItem("user", JSON.stringify(user))
      localStorage.setItem("authToken", user.token)

      setIsLoading(false)
      onLogin(user)
    }, 1500)
  }

  const neonBlue = isDark ? "shadow-[0_0_20px_rgba(0,212,255,0.6)]" : "shadow-[0_0_15px_rgba(0,149,255,0.4)]"

  return (
    <div
      className={`min-h-screen flex items-center justify-center transition-colors duration-500 ${
        isDark
          ? "bg-gradient-to-br from-[#0a0e27] via-[#1a1a2e] to-[#16213e]"
          : "bg-gradient-to-br from-white via-gray-50 to-blue-50"
      }`}
      style={{ fontFamily: "'Inter', 'Poppins', sans-serif" }}
    >
      {/* Language & Theme Toggle - Top Right */}
      <div className="absolute top-4 right-4 flex items-center gap-3">
        {/* Language Toggle */}
        <div className="flex items-center gap-2">
          <span className={`text-sm font-medium ${lang === "id" ? "text-cyan-400" : "text-gray-500"}`}>ID</span>
          <Switch checked={lang === "en"} onCheckedChange={(checked) => setLang(checked ? "en" : "id")} />
          <span className={`text-sm font-medium ${lang === "en" ? "text-cyan-400" : "text-gray-500"}`}>EN</span>
        </div>

        {/* Theme Toggle */}
        <Button
          onClick={() => setIsDark(!isDark)}
          variant="outline"
          size="icon"
          className={`rounded-full transition-all hover:scale-110 ${
            isDark
              ? "border-cyan-500/50 bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-400"
              : "border-blue-300 hover:bg-blue-50 text-blue-600"
          } ${neonBlue}`}
        >
          {isDark ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
        </Button>
      </div>

      <div className="w-full max-w-md px-4">
        <Card
          className={`border-2 backdrop-blur-sm ${
            isDark ? "bg-[#1a1a2e]/90 border-cyan-500/30" : "bg-white/90 border-blue-200"
          } ${neonBlue}`}
        >
          <CardContent className="pt-8 pb-8">
            {/* Logo */}
            <div className="flex flex-col items-center mb-8">
              <img
                src="/images/api-attachments-bx4bhnk5pzjvdxoq0v9or.png"
                alt="Logo"
                className={`w-20 h-20 object-contain mb-4 ${
                  isDark ? "drop-shadow-[0_0_15px_rgba(0,212,255,0.8)]" : ""
                }`}
              />
              <h1
                className={`text-2xl font-bold text-center ${
                  isDark ? "text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-500" : "text-gray-900"
                }`}
              >
                {t.appName}
              </h1>
              <p className={`text-sm mt-2 ${isDark ? "text-gray-400" : "text-gray-600"}`}>{t.login}</p>
            </div>

            {/* Login Form */}
            <form onSubmit={handleSubmit} className="space-y-5">
              {/* Email Input */}
              <div>
                <Label htmlFor="email" className={isDark ? "text-gray-300" : "text-gray-700"}>
                  {t.email}
                </Label>
                <div className="relative mt-1">
                  <Mail
                    className={`absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 ${
                      isDark ? "text-cyan-400" : "text-blue-500"
                    }`}
                  />
                  <Input
                    id="email"
                    type="text"
                    value={email}
                    onChange={(e) => {
                      setEmail(e.target.value)
                      setError("")
                    }}
                    placeholder="email@example.com"
                    className={`pl-11 h-12 rounded-xl transition-all ${
                      isDark
                        ? "bg-[#0a0e27]/50 border-cyan-500/30 text-white focus:border-cyan-400 focus:ring-2 focus:ring-cyan-400/20"
                        : "bg-white border-blue-200 focus:border-blue-400 focus:ring-2 focus:ring-blue-400/20"
                    }`}
                    disabled={isLoading}
                  />
                </div>
              </div>

              {/* Password Input */}
              <div>
                <Label htmlFor="password" className={isDark ? "text-gray-300" : "text-gray-700"}>
                  {t.password}
                </Label>
                <div className="relative mt-1">
                  <Lock
                    className={`absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 ${
                      isDark ? "text-cyan-400" : "text-blue-500"
                    }`}
                  />
                  <Input
                    id="password"
                    type={showPassword ? "text" : "password"}
                    value={password}
                    onChange={(e) => {
                      setPassword(e.target.value)
                      setError("")
                    }}
                    placeholder="••••••••"
                    className={`pl-11 pr-11 h-12 rounded-xl transition-all ${
                      isDark
                        ? "bg-[#0a0e27]/50 border-cyan-500/30 text-white focus:border-cyan-400 focus:ring-2 focus:ring-cyan-400/20"
                        : "bg-white border-blue-200 focus:border-blue-400 focus:ring-2 focus:ring-blue-400/20"
                    }`}
                    disabled={isLoading}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className={`absolute right-3 top-1/2 -translate-y-1/2 ${
                      isDark ? "text-gray-400 hover:text-cyan-400" : "text-gray-500 hover:text-blue-500"
                    } transition-colors`}
                    disabled={isLoading}
                  >
                    {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
              </div>

              {/* Error Message */}
              {error && (
                <div
                  className={`p-3 rounded-xl text-sm font-medium ${
                    isDark
                      ? "bg-red-500/10 border border-red-500/30 text-red-400"
                      : "bg-red-50 border border-red-200 text-red-700"
                  }`}
                >
                  {error}
                </div>
              )}

              {/* Forgot Password */}
              <div className="text-right">
                <button
                  type="button"
                  className={`text-sm font-medium transition-colors ${
                    isDark ? "text-cyan-400 hover:text-cyan-300" : "text-blue-600 hover:text-blue-700"
                  }`}
                  disabled={isLoading}
                >
                  {t.forgotPassword}
                </button>
              </div>

              {/* Login Button */}
              <Button
                type="submit"
                disabled={isLoading}
                className={`w-full h-12 rounded-xl font-semibold text-base transition-all hover:scale-105 active:scale-95 ${
                  isDark
                    ? "bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-400 hover:to-blue-400 text-white"
                    : "bg-gradient-to-r from-blue-500 to-cyan-500 hover:from-blue-600 hover:to-cyan-600 text-white"
                } ${neonBlue} ${isLoading ? "opacity-70 cursor-not-allowed" : ""}`}
              >
                {isLoading ? (
                  <div className="flex items-center gap-2">
                    <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    {t.loggingIn}
                  </div>
                ) : (
                  t.loginButton
                )}
              </Button>
            </form>
          </CardContent>
        </Card>

        {/* Info Text */}
        <p className={`text-center text-sm mt-6 ${isDark ? "text-gray-400" : "text-gray-600"}`}>
          {lang === "id"
            ? "Masukkan email/username dan password minimal 8 karakter"
            : "Enter email/username and password (min 8 characters)"}
        </p>
      </div>
    </div>
  )
}

export default function SavingsApp() {
  const [user, setUser] = useState<AuthUser | null>(null)
  const [isCheckingAuth, setIsCheckingAuth] = useState(true)

  const [lang, setLang] = useState<Language>("id")
  const t = translations[lang]

  const [isDark, setIsDark] = useState(false)

  const [monthlyAmount, setMonthlyAmount] = useState("")
  const [monthName, setMonthName] = useState("")
  const [transactionType, setTransactionType] = useState<"income" | "expense" | "saving">("saving")
  const [targetAmount, setTargetAmount] = useState("")
  const [targetDuration, setTargetDuration] = useState("")
  const [records, setRecords] = useState<SavingRecord[]>([])
  const [target, setTarget] = useState<{ total: number; duration: number } | null>(null)
  const [editingRecord, setEditingRecord] = useState<string | null>(null)
  const [isEditingTarget, setIsEditingTarget] = useState(false)
  const [hasTriggeredConfetti, setHasTriggeredConfetti] = useState(false)

  useEffect(() => {
    const savedUser = localStorage.getItem("user")
    const savedToken = localStorage.getItem("authToken")

    if (savedUser && savedToken) {
      const parsedUser: AuthUser = JSON.parse(savedUser)
      setUser(parsedUser)
    }

    setIsCheckingAuth(false)
  }, [])

  // Load data from localStorage on mount
  useEffect(() => {
    const savedRecords = localStorage.getItem("savingRecords")
    const savedTarget = localStorage.getItem("savingTarget")
    const savedTheme = localStorage.getItem("theme")
    const savedLang = localStorage.getItem("language")

    if (savedRecords) setRecords(JSON.parse(savedRecords))
    if (savedTarget) setTarget(JSON.parse(savedTarget))
    if (savedTheme) setIsDark(savedTheme === "dark")
    if (savedLang) setLang(savedLang as Language)
  }, [])

  // Save records to localStorage
  useEffect(() => {
    if (records.length > 0) {
      localStorage.setItem("savingRecords", JSON.stringify(records))
    }
  }, [records])

  // Save target to localStorage
  useEffect(() => {
    if (target) {
      localStorage.setItem("savingTarget", JSON.stringify(target))
    }
  }, [target])

  // Save theme to localStorage
  useEffect(() => {
    localStorage.setItem("theme", isDark ? "dark" : "light")
  }, [isDark])

  useEffect(() => {
    localStorage.setItem("language", lang)
  }, [lang])

  const totalIncome = records.filter((r) => r.type === "income").reduce((sum, record) => sum + record.amount, 0)
  const totalExpense = records.filter((r) => r.type === "expense").reduce((sum, record) => sum + record.amount, 0)
  // Auto-calculate savings: total savings = income - expenses
  const totalSavings = totalIncome - totalExpense

  // Calculate real-time percentages
  const expensePercentage = totalIncome > 0 ? (totalExpense / totalIncome) * 100 : 0
  const savingsPercentage = totalIncome > 0 ? (totalSavings / totalIncome) * 100 : 0

  // Calculate progress percentage
  const progressPercentage = target ? Math.min((totalSavings / target.total) * 100, 100) : 0

  // Trigger confetti when target is reached
  useEffect(() => {
    if (target && totalSavings >= target.total && !hasTriggeredConfetti && records.length > 0) {
      confetti({
        particleCount: 150,
        spread: 80,
        origin: { y: 0.6 },
        colors: ["#00ff88", "#00d4ff", "#ff00ff", "#ffff00"],
      })
      setHasTriggeredConfetti(true)
    }
    if (target && totalSavings < target.total) {
      setHasTriggeredConfetti(false)
    }
  }, [totalSavings, target, hasTriggeredConfetti, records.length])

  const formatRupiah = (amount: number) => {
    return new Intl.NumberFormat("id-ID", {
      style: "currency",
      currency: "IDR",
      minimumFractionDigits: 0,
      maximumFractionDigits: 0,
    }).format(amount)
  }

  const handleSaveRecord = () => {
    if (!monthlyAmount || !monthName || isNaN(Number(monthlyAmount))) return

    if (editingRecord) {
      setRecords(
        records.map((r) =>
          r.id === editingRecord ? { ...r, month: monthName, amount: Number(monthlyAmount), type: transactionType } : r,
        ),
      )
      setEditingRecord(null)
    } else {
      const newRecord: SavingRecord = {
        id: Date.now().toString(),
        month: monthName,
        amount: Number(monthlyAmount),
        type: transactionType,
      }
      setRecords([...records, newRecord])
    }

    setMonthlyAmount("")
    setMonthName("")
    setTransactionType("saving")
  }

  const handleDeleteRecord = (id: string) => {
    setRecords(records.filter((r) => r.id !== id))
  }

  const handleEditRecord = (record: SavingRecord) => {
    setMonthName(record.month)
    setMonthlyAmount(record.amount.toString())
    setTransactionType(record.type)
    setEditingRecord(record.id)
  }

  const handleSaveTarget = () => {
    if (!targetAmount || !targetDuration || isNaN(Number(targetAmount)) || isNaN(Number(targetDuration))) return

    setTarget({
      total: Number(targetAmount),
      duration: Number(targetDuration),
    })
    setIsEditingTarget(false)
    setTargetAmount("")
    setTargetDuration("")
  }

  const handleEditTarget = () => {
    if (target) {
      setTargetAmount(target.total.toString())
      setTargetDuration(target.duration.toString())
      setIsEditingTarget(true)
    }
  }

  const handleDeleteTarget = () => {
    setTarget(null)
    localStorage.removeItem("savingTarget")
    setIsEditingTarget(false)
  }

  const handleLogout = () => {
    logoutUser()
    setUser(null)
  }

  if (isCheckingAuth) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-[#0a0e27] via-[#1a1a2e] to-[#16213e]">
        <div className="w-12 h-12 border-4 border-cyan-500 border-t-transparent rounded-full animate-spin" />
      </div>
    )
  }

  if (!user) {
    return <AuthPage onLogin={setUser} isDark={isDark} lang={lang} setLang={setLang} setIsDark={setIsDark} />
  }

  const neonBlue = isDark ? "shadow-[0_0_15px_rgba(0,212,255,0.5)]" : "shadow-[0_0_10px_rgba(0,149,255,0.3)]"
  const neonGreen = isDark ? "shadow-[0_0_15px_rgba(0,255,136,0.5)]" : "shadow-[0_0_10px_rgba(0,200,100,0.3)]"
  const neonPurple = isDark ? "shadow-[0_0_15px_rgba(255,0,255,0.5)]" : "shadow-[0_0_10px_rgba(200,0,200,0.3)]"

  return (
    <div
      className={`min-h-screen transition-colors duration-500 ${
        isDark
          ? "bg-gradient-to-br from-[#0a0e27] via-[#1a1a2e] to-[#16213e]"
          : "bg-gradient-to-br from-white via-gray-50 to-blue-50"
      }`}
      style={{ fontFamily: "'Inter', 'Poppins', sans-serif" }}
    >
      {/* Header with neon accent */}
      <header
        className={`border-b backdrop-blur-sm sticky top-0 z-50 ${
          isDark
            ? "bg-[#0a0e27]/80 border-cyan-500/20 shadow-[0_4px_20px_rgba(0,212,255,0.1)]"
            : "bg-white/80 border-blue-200/50 shadow-sm"
        }`}
      >
        <div className="max-w-6xl mx-auto py-4 px-4 sm:px-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <img
                src="/images/api-attachments-bx4bhnk5pzjvdxoq0v9or.png"
                alt="Logo"
                className={`w-10 h-10 sm:w-12 sm:h-12 object-contain ${isDark ? "drop-shadow-[0_0_8px_rgba(0,212,255,0.6)]" : ""}`}
              />
              <h1
                className={`text-lg sm:text-2xl font-bold ${
                  isDark ? "text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-500" : "text-gray-900"
                }`}
              >
                {t.appName}
              </h1>
            </div>

            <div className="flex items-center gap-3">
              {/* Language Toggle */}
              <div className="flex items-center gap-2">
                <span className={`text-sm font-medium ${lang === "id" ? "text-cyan-400" : "text-gray-500"}`}>ID</span>
                <Switch checked={lang === "en"} onCheckedChange={(checked) => setLang(checked ? "en" : "id")} />
                <span className={`text-sm font-medium ${lang === "en" ? "text-cyan-400" : "text-gray-500"}`}>EN</span>
              </div>

              {/* Theme Toggle */}
              <Button
                onClick={() => setIsDark(!isDark)}
                variant="outline"
                size="icon"
                className={`rounded-full transition-all hover:scale-110 ${
                  isDark
                    ? "border-cyan-500/50 bg-cyan-500/10 hover:bg-cyan-500/20 text-cyan-400"
                    : "border-blue-300 hover:bg-blue-50 text-blue-600"
                } ${neonBlue}`}
              >
                {isDark ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
              </Button>

              <Button
                onClick={handleLogout}
                variant="outline"
                size="icon"
                className={`rounded-full transition-all hover:scale-110 ${
                  isDark
                    ? "border-red-500/50 bg-red-500/10 hover:bg-red-500/20 text-red-400"
                    : "border-red-300 hover:bg-red-50 text-red-600"
                }`}
                title={t.logout}
              >
                <LogOut className="h-5 w-5" />
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-6xl mx-auto p-4 sm:p-6 space-y-6">
        {/* Updated financial calculations to automatically calculate savings and percentages */}
        {/* Financial Overview Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          {/* Income Card */}
          <Card
            className={`border-2 transition-all hover:scale-105 ${
              isDark
                ? "bg-gradient-to-br from-green-500/10 to-emerald-500/5 border-green-500/30 hover:border-green-400/50"
                : "bg-gradient-to-br from-green-50 to-emerald-50 border-green-200 hover:border-green-300"
            } ${neonGreen}`}
          >
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className={`text-sm font-medium ${isDark ? "text-green-400" : "text-green-700"}`}>
                    {t.totalIncome}
                  </p>
                  <p className={`text-2xl font-bold mt-1 ${isDark ? "text-green-300" : "text-green-800"}`}>
                    {formatRupiah(totalIncome)}
                  </p>
                  <p className={`text-xs mt-1 ${isDark ? "text-green-400/70" : "text-green-600"}`}>100% dari total</p>
                </div>
                <div className={`p-3 rounded-full ${isDark ? "bg-green-500/20" : "bg-green-200"}`}>
                  <TrendingUp className={`w-6 h-6 ${isDark ? "text-green-400" : "text-green-700"}`} />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Expense Card */}
          <Card
            className={`border-2 transition-all hover:scale-105 ${
              isDark
                ? "bg-gradient-to-br from-red-500/10 to-pink-500/5 border-red-500/30 hover:border-red-400/50"
                : "bg-gradient-to-br from-red-50 to-pink-50 border-red-200 hover:border-red-300"
            } ${neonPurple}`}
          >
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className={`text-sm font-medium ${isDark ? "text-red-400" : "text-red-700"}`}>{t.totalExpense}</p>
                  <p className={`text-2xl font-bold mt-1 ${isDark ? "text-red-300" : "text-red-800"}`}>
                    {formatRupiah(totalExpense)}
                  </p>
                  <p className={`text-xs mt-1 ${isDark ? "text-red-400/70" : "text-red-600"}`}>
                    {expensePercentage.toFixed(1)}% dari pemasukan
                  </p>
                </div>
                <div className={`p-3 rounded-full ${isDark ? "bg-red-500/20" : "bg-red-200"}`}>
                  <Wallet className={`w-6 h-6 ${isDark ? "text-red-400" : "text-red-700"}`} />
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Saving Card */}
          <Card
            className={`border-2 transition-all hover:scale-105 ${
              isDark
                ? "bg-gradient-to-br from-cyan-500/10 to-blue-500/5 border-cyan-500/30 hover:border-cyan-400/50"
                : "bg-gradient-to-br from-cyan-50 to-blue-50 border-cyan-200 hover:border-cyan-300"
            } ${neonBlue}`}
          >
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className={`text-sm font-medium ${isDark ? "text-cyan-400" : "text-cyan-700"}`}>{t.totalSaving}</p>
                  <p className={`text-2xl font-bold mt-1 ${isDark ? "text-cyan-300" : "text-cyan-800"}`}>
                    {formatRupiah(totalSavings)}
                  </p>
                  <p className={`text-xs mt-1 ${isDark ? "text-cyan-400/70" : "text-cyan-600"}`}>
                    {savingsPercentage.toFixed(1)}% dari pemasukan
                  </p>
                </div>
                <div className={`p-3 rounded-full ${isDark ? "bg-cyan-500/20" : "bg-cyan-200"}`}>
                  <PieChart className={`w-6 h-6 ${isDark ? "text-cyan-400" : "text-cyan-700"}`} />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Bar Chart */}
          <Card
            className={`border-2 ${
              isDark ? "bg-[#0f1729]/80 backdrop-blur-sm border-cyan-500/20" : "bg-white border-gray-200"
            }`}
          >
            <CardHeader>
              <CardTitle className={isDark ? "text-cyan-400" : "text-gray-900"}>Grafik Perbandingan Keuangan</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {/* Income Bar */}
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className={`text-sm font-medium ${isDark ? "text-green-400" : "text-green-700"}`}>
                      {t.totalIncome}
                    </span>
                    <span className={`text-sm font-bold ${isDark ? "text-green-300" : "text-green-800"}`}>
                      {formatRupiah(totalIncome)}
                    </span>
                  </div>
                  <div className="relative group">
                    <div
                      className={`w-full h-8 rounded-lg overflow-hidden ${isDark ? "bg-[#0a0e27]/50" : "bg-gray-200"}`}
                    >
                      <div
                        className="h-full transition-all duration-1000 ease-out bg-gradient-to-r from-green-500 to-emerald-500"
                        style={{ width: totalIncome > 0 ? "100%" : "0%" }}
                      />
                    </div>
                    {/* Tooltip */}
                    <div className="absolute left-1/2 -translate-x-1/2 -top-12 opacity-0 group-hover:opacity-100 transition-opacity bg-black/90 text-white px-3 py-2 rounded-lg text-xs whitespace-nowrap pointer-events-none">
                      {formatRupiah(totalIncome)} (100%)
                    </div>
                  </div>
                </div>

                {/* Expense Bar */}
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className={`text-sm font-medium ${isDark ? "text-red-400" : "text-red-700"}`}>
                      {t.totalExpense}
                    </span>
                    <span className={`text-sm font-bold ${isDark ? "text-red-300" : "text-red-800"}`}>
                      {formatRupiah(totalExpense)} ({expensePercentage.toFixed(1)}%)
                    </span>
                  </div>
                  <div className="relative group">
                    <div
                      className={`w-full h-8 rounded-lg overflow-hidden ${isDark ? "bg-[#0a0e27]/50" : "bg-gray-200"}`}
                    >
                      <div
                        className="h-full transition-all duration-1000 ease-out bg-gradient-to-r from-red-500 to-pink-500"
                        style={{ width: `${totalIncome > 0 ? expensePercentage : 0}%` }}
                      />
                    </div>
                    {/* Tooltip */}
                    <div className="absolute left-1/2 -translate-x-1/2 -top-12 opacity-0 group-hover:opacity-100 transition-opacity bg-black/90 text-white px-3 py-2 rounded-lg text-xs whitespace-nowrap pointer-events-none">
                      {formatRupiah(totalExpense)} ({expensePercentage.toFixed(1)}%)
                    </div>
                  </div>
                </div>

                {/* Savings Bar */}
                <div className="space-y-2">
                  <div className="flex justify-between items-center">
                    <span className={`text-sm font-medium ${isDark ? "text-cyan-400" : "text-cyan-700"}`}>
                      {t.totalSaving}
                    </span>
                    <span className={`text-sm font-bold ${isDark ? "text-cyan-300" : "text-cyan-800"}`}>
                      {formatRupiah(totalSavings)} ({savingsPercentage.toFixed(1)}%)
                    </span>
                  </div>
                  <div className="relative group">
                    <div
                      className={`w-full h-8 rounded-lg overflow-hidden ${isDark ? "bg-[#0a0e27]/50" : "bg-gray-200"}`}
                    >
                      <div
                        className="h-full transition-all duration-1000 ease-out bg-gradient-to-r from-cyan-500 to-blue-500"
                        style={{ width: `${totalIncome > 0 ? savingsPercentage : 0}%` }}
                      />
                    </div>
                    {/* Tooltip */}
                    <div className="absolute left-1/2 -translate-x-1/2 -top-12 opacity-0 group-hover:opacity-100 transition-opacity bg-black/90 text-white px-3 py-2 rounded-lg text-xs whitespace-nowrap pointer-events-none">
                      {formatRupiah(totalSavings)} ({savingsPercentage.toFixed(1)}%)
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Pie Chart */}
          <Card
            className={`border-2 ${
              isDark ? "bg-[#0f1729]/80 backdrop-blur-sm border-cyan-500/20" : "bg-white border-gray-200"
            }`}
          >
            <CardHeader>
              <CardTitle className={isDark ? "text-cyan-400" : "text-gray-900"}>Distribusi Keuangan</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-col items-center space-y-6">
                {/* Pie Chart Visualization */}
                <div className="relative w-56 h-56 group">
                  <svg className="w-56 h-56 transform -rotate-90">
                    {totalIncome > 0 ? (
                      <>
                        {/* Expense Segment */}
                        <circle
                          cx="112"
                          cy="112"
                          r="80"
                          fill="none"
                          stroke="url(#expenseGradient)"
                          strokeWidth="40"
                          strokeDasharray={`${(expensePercentage / 100) * 2 * Math.PI * 80} ${2 * Math.PI * 80}`}
                          className="transition-all duration-1000 ease-out hover:stroke-width-45"
                          style={{
                            filter: isDark ? "drop-shadow(0 0 8px rgba(239,68,68,0.5))" : "none",
                          }}
                        />
                        {/* Savings Segment */}
                        <circle
                          cx="112"
                          cy="112"
                          r="80"
                          fill="none"
                          stroke="url(#savingsGradient)"
                          strokeWidth="40"
                          strokeDasharray={`${(savingsPercentage / 100) * 2 * Math.PI * 80} ${2 * Math.PI * 80}`}
                          strokeDashoffset={`${-(expensePercentage / 100) * 2 * Math.PI * 80}`}
                          className="transition-all duration-1000 ease-out hover:stroke-width-45"
                          style={{
                            filter: isDark ? "drop-shadow(0 0 8px rgba(0,212,255,0.5))" : "none",
                          }}
                        />
                      </>
                    ) : (
                      <circle
                        cx="112"
                        cy="112"
                        r="80"
                        fill="none"
                        stroke={isDark ? "#1a1a2e" : "#e5e7eb"}
                        strokeWidth="40"
                      />
                    )}
                    <defs>
                      <linearGradient id="expenseGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                        <stop offset="0%" stopColor="#ef4444" />
                        <stop offset="100%" stopColor="#ec4899" />
                      </linearGradient>
                      <linearGradient id="savingsGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                        <stop offset="0%" stopColor="#06b6d4" />
                        <stop offset="100%" stopColor="#3b82f6" />
                      </linearGradient>
                    </defs>
                  </svg>
                  <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none">
                    <span className={`text-lg font-medium ${isDark ? "text-gray-400" : "text-gray-600"}`}>Total</span>
                    <span className={`text-2xl font-bold ${isDark ? "text-cyan-300" : "text-gray-900"}`}>
                      {formatRupiah(totalIncome)}
                    </span>
                  </div>
                </div>

                {/* Legend */}
                <div className="space-y-3 w-full">
                  <div className="flex items-center justify-between group cursor-pointer">
                    <div className="flex items-center space-x-3">
                      <div className="w-4 h-4 rounded-full bg-gradient-to-r from-green-500 to-emerald-500 group-hover:scale-110 transition-transform" />
                      <span className={`text-sm ${isDark ? "text-gray-300" : "text-gray-700"}`}>{t.totalIncome}</span>
                    </div>
                    <span className={`text-sm font-bold ${isDark ? "text-green-400" : "text-green-700"}`}>100%</span>
                  </div>
                  <div className="flex items-center justify-between group cursor-pointer">
                    <div className="flex items-center space-x-3">
                      <div className="w-4 h-4 rounded-full bg-gradient-to-r from-red-500 to-pink-500 group-hover:scale-110 transition-transform" />
                      <span className={`text-sm ${isDark ? "text-gray-300" : "text-gray-700"}`}>{t.totalExpense}</span>
                    </div>
                    <span className={`text-sm font-bold ${isDark ? "text-red-400" : "text-red-700"}`}>
                      {expensePercentage.toFixed(1)}%
                    </span>
                  </div>
                  <div className="flex items-center justify-between group cursor-pointer">
                    <div className="flex items-center space-x-3">
                      <div className="w-4 h-4 rounded-full bg-gradient-to-r from-cyan-500 to-blue-500 group-hover:scale-110 transition-transform" />
                      <span className={`text-sm ${isDark ? "text-gray-300" : "text-gray-700"}`}>{t.totalSaving}</span>
                    </div>
                    <span className={`text-sm font-bold ${isDark ? "text-cyan-400" : "text-cyan-700"}`}>
                      {savingsPercentage.toFixed(1)}%
                    </span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Target Progress Display - conditionally rendered */}
        {target && (
          <Card
            className={`border-2 ${
              isDark
                ? "bg-gradient-to-br from-cyan-500/5 to-purple-500/5 border-cyan-500/20"
                : "bg-gradient-to-br from-blue-50 to-purple-50 border-blue-200"
            } ${neonBlue}`}
          >
            <CardHeader>
              <CardTitle className={isDark ? "text-cyan-400" : "text-gray-900"}>{t.targetSavings}</CardTitle>
              <div className="flex gap-2 mt-2">
                <Button
                  onClick={() => setIsEditingTarget(true)}
                  size="sm"
                  variant="outline"
                  className={`${
                    isDark
                      ? "border-cyan-500/30 text-cyan-400 hover:bg-cyan-500/10"
                      : "border-blue-300 text-blue-700 hover:bg-blue-50"
                  }`}
                >
                  <Edit2 className="w-3 h-3 mr-1" />
                  {t.edit}
                </Button>
                <Button
                  onClick={handleDeleteTarget}
                  size="sm"
                  variant="outline"
                  className={`${
                    isDark
                      ? "border-red-500/30 text-red-400 hover:bg-red-500/10"
                      : "border-red-300 text-red-700 hover:bg-red-50"
                  }`}
                >
                  <Trash2 className="w-3 h-3 mr-1" />
                  {t.delete}
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex justify-between">
                <div>
                  <p className={`text-sm ${isDark ? "text-gray-400" : "text-gray-600"}`}>{t.targetAmount}</p>
                  <p className={`text-xl font-bold ${isDark ? "text-cyan-300" : "text-blue-900"}`}>
                    {formatRupiah(target.total)}
                  </p>
                </div>
                <div>
                  <p className={`text-sm ${isDark ? "text-gray-400" : "text-gray-600"}`}>{t.durationMonths}</p>
                  <p className={`text-xl font-bold ${isDark ? "text-purple-400" : "text-purple-700"}`}>
                    {target.duration} {t.months}
                  </p>
                </div>
              </div>

              {/* Progress Bar */}
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className={isDark ? "text-gray-400" : "text-gray-600"}>{t.progress}</span>
                  <span className={`font-bold ${isDark ? "text-cyan-400" : "text-blue-600"}`}>
                    {progressPercentage.toFixed(1)}%
                  </span>
                </div>
                <div
                  className={`w-full h-6 rounded-full overflow-hidden ${isDark ? "bg-[#0a0e27]/50" : "bg-gray-200"}`}
                >
                  <div
                    className={`h-full transition-all duration-1000 ease-out ${
                      isDark
                        ? "bg-gradient-to-r from-cyan-500 via-blue-500 to-purple-500"
                        : "bg-gradient-to-r from-cyan-500 to-blue-500"
                    } ${neonBlue}`}
                    style={{ width: `${progressPercentage}%` }}
                  />
                </div>
              </div>

              {/* Circular Progress */}
              <div className="flex justify-center py-4">
                <div className="relative w-48 h-48">
                  <svg className="transform -rotate-90 w-48 h-48">
                    <circle
                      cx="96"
                      cy="96"
                      r="88"
                      stroke={isDark ? "#1a1a2e" : "#e5e7eb"}
                      strokeWidth="16"
                      fill="none"
                    />
                    <circle
                      cx="96"
                      cy="96"
                      r="88"
                      stroke="url(#progressGradient)"
                      strokeWidth="16"
                      fill="none"
                      strokeLinecap="round"
                      strokeDasharray={`${2 * Math.PI * 88}`}
                      strokeDashoffset={`${2 * Math.PI * 88 * (1 - progressPercentage / 100)}`}
                      className="transition-all duration-1000 ease-out"
                      style={{
                        filter: isDark ? "drop-shadow(0 0 8px rgba(0,212,255,0.6))" : "none",
                      }}
                    />
                    <defs>
                      <linearGradient id="progressGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                        <stop offset="0%" stopColor="#00d4ff" />
                        <stop offset="50%" stopColor="#3b82f6" />
                        <stop offset="100%" stopColor="#a855f7" />
                      </linearGradient>
                    </defs>
                  </svg>
                  <div className="absolute inset-0 flex flex-col items-center justify-center">
                    <span
                      className={`text-4xl font-bold ${
                        isDark
                          ? "text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-500"
                          : "text-gray-900"
                      }`}
                    >
                      {progressPercentage.toFixed(0)}%
                    </span>
                    {progressPercentage >= 100 && (
                      <span className="text-sm mt-2 text-green-400 font-semibold animate-pulse">
                        {t.congratulations}
                      </span>
                    )}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Transaction Input */}
          <Card
            className={`border-2 ${
              isDark
                ? "bg-[#1a1a2e]/80 border-cyan-500/20 backdrop-blur-sm"
                : "bg-white/80 border-blue-200 backdrop-blur-sm"
            }`}
          >
            <CardHeader>
              <CardTitle
                className={`flex items-center gap-2 ${
                  isDark ? "text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-500" : "text-gray-900"
                }`}
              >
                <Plus className="w-5 h-5" />
                {editingRecord ? t.editTransaction : t.addTransaction}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="month" className={isDark ? "text-gray-300" : "text-gray-700"}>
                  {t.monthYear}
                </Label>
                <div className="relative mt-1">
                  <Calendar
                    className={`absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 ${
                      isDark ? "text-cyan-400" : "text-blue-500"
                    }`}
                  />
                  <Input
                    id="month"
                    value={monthName}
                    onChange={(e) => setMonthName(e.target.value)}
                    placeholder={t.monthPlaceholder}
                    className={`pl-10 rounded-xl ${
                      isDark
                        ? "bg-[#0a0e27]/50 border-cyan-500/30 text-white focus:border-cyan-400"
                        : "bg-white border-blue-200 focus:border-blue-400"
                    }`}
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="amount" className={isDark ? "text-gray-300" : "text-gray-700"}>
                  {t.amount}
                </Label>
                <Input
                  id="amount"
                  type="number"
                  value={monthlyAmount}
                  onChange={(e) => setMonthlyAmount(e.target.value)}
                  placeholder={t.amountPlaceholder}
                  className={`mt-1 rounded-xl ${
                    isDark
                      ? "bg-[#0a0e27]/50 border-cyan-500/30 text-white focus:border-cyan-400"
                      : "bg-white border-blue-200 focus:border-blue-400"
                  }`}
                />
              </div>

              <div>
                <Label className={isDark ? "text-gray-300" : "text-gray-700"}>{t.type}</Label>
                <div className="grid grid-cols-3 gap-2 mt-1">
                  <Button
                    type="button"
                    onClick={() => setTransactionType("income")}
                    variant="outline"
                    className={`rounded-xl transition-all ${
                      transactionType === "income"
                        ? isDark
                          ? "bg-green-500/20 border-green-400 text-green-400"
                          : "bg-green-100 border-green-500 text-green-700"
                        : isDark
                          ? "border-gray-700 text-gray-400 hover:border-green-400/50"
                          : "border-gray-300 text-gray-600 hover:border-green-400"
                    }`}
                  >
                    {t.income}
                  </Button>
                  <Button
                    type="button"
                    onClick={() => setTransactionType("expense")}
                    variant="outline"
                    className={`rounded-xl transition-all ${
                      transactionType === "expense"
                        ? isDark
                          ? "bg-red-500/20 border-red-400 text-red-400"
                          : "bg-red-100 border-red-500 text-red-700"
                        : isDark
                          ? "border-gray-700 text-gray-400 hover:border-red-400/50"
                          : "border-gray-300 text-gray-600 hover:border-red-400"
                    }`}
                  >
                    {t.expense}
                  </Button>
                  <Button
                    type="button"
                    onClick={() => setTransactionType("saving")}
                    variant="outline"
                    className={`rounded-xl transition-all ${
                      transactionType === "saving"
                        ? isDark
                          ? "bg-cyan-500/20 border-cyan-400 text-cyan-400"
                          : "bg-cyan-100 border-cyan-500 text-cyan-700"
                        : isDark
                          ? "border-gray-700 text-gray-400 hover:border-cyan-400/50"
                          : "border-gray-300 text-gray-600 hover:border-cyan-400"
                    }`}
                  >
                    {t.saving}
                  </Button>
                </div>
              </div>

              <Button
                onClick={handleSaveRecord}
                className={`w-full rounded-xl font-semibold transition-all hover:scale-105 active:scale-95 ${
                  isDark
                    ? "bg-gradient-to-r from-cyan-500 to-blue-500 hover:from-cyan-400 hover:to-blue-400 text-white"
                    : "bg-gradient-to-r from-blue-500 to-cyan-500 hover:from-blue-600 hover:to-cyan-600 text-white"
                } ${neonBlue}`}
              >
                {editingRecord ? t.update : t.save}
              </Button>
            </CardContent>
          </Card>

          {/* Target Savings */}
          <Card
            className={`border-2 ${
              isDark
                ? "bg-[#1a1a2e]/80 border-cyan-500/20 backdrop-blur-sm"
                : "bg-white/80 border-blue-200 backdrop-blur-sm"
            }`}
          >
            <CardHeader>
              <CardTitle
                className={`flex items-center gap-2 ${
                  isDark ? "text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-500" : "text-gray-900"
                }`}
              >
                <Plus className="w-5 h-5" />
                {t.targetSavings}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {!target || isEditingTarget ? (
                <>
                  <div>
                    <Label htmlFor="target" className={isDark ? "text-gray-300" : "text-gray-700"}>
                      {t.totalTarget}
                    </Label>
                    <Input
                      id="target"
                      type="number"
                      value={targetAmount}
                      onChange={(e) => setTargetAmount(e.target.value)}
                      placeholder={t.amountPlaceholder}
                      className={`mt-1 rounded-xl ${
                        isDark
                          ? "bg-[#0a0e27]/50 border-cyan-500/30 text-white focus:border-cyan-400"
                          : "bg-white border-blue-200 focus:border-blue-400"
                      }`}
                    />
                  </div>
                  <div>
                    <Label htmlFor="duration" className={isDark ? "text-gray-300" : "text-gray-700"}>
                      {t.duration}
                    </Label>
                    <Input
                      id="duration"
                      type="number"
                      value={targetDuration}
                      onChange={(e) => setTargetDuration(e.target.value)}
                      placeholder={t.durationPlaceholder}
                      className={`mt-1 rounded-xl ${
                        isDark
                          ? "bg-[#0a0e27]/50 border-cyan-500/30 text-white focus:border-cyan-400"
                          : "bg-white border-blue-200 focus:border-blue-400"
                      }`}
                    />
                  </div>
                  <Button
                    onClick={handleSaveTarget}
                    className={`w-full rounded-xl font-semibold transition-all hover:scale-105 active:scale-95 ${
                      isDark
                        ? "bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-400 hover:to-emerald-400 text-white"
                        : "bg-gradient-to-r from-green-500 to-emerald-500 hover:from-green-600 hover:to-emerald-600 text-white"
                    } ${neonGreen}`}
                  >
                    {isEditingTarget ? t.updateTarget : t.setTarget}
                  </Button>
                </>
              ) : (
                <>
                  <div className="space-y-3">
                    <div
                      className={`flex justify-between items-center p-4 rounded-xl ${
                        isDark ? "bg-[#0a0e27]/50" : "bg-gray-50"
                      }`}
                    >
                      <span className={isDark ? "text-gray-400" : "text-gray-600"}>{t.totalTarget}</span>
                      <span className={`font-bold text-lg ${isDark ? "text-cyan-400" : "text-blue-600"}`}>
                        {formatRupiah(target.total)}
                      </span>
                    </div>
                    <div
                      className={`flex justify-between items-center p-4 rounded-xl ${
                        isDark ? "bg-[#0a0e27]/50" : "bg-gray-50"
                      }`}
                    >
                      <span className={isDark ? "text-gray-400" : "text-gray-600"}>{t.durationMonths}</span>
                      <span className={`font-bold text-lg ${isDark ? "text-cyan-400" : "text-blue-600"}`}>
                        {target.duration} {t.months}
                      </span>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button
                      onClick={handleEditTarget}
                      variant="outline"
                      className={`flex-1 rounded-xl transition-all hover:scale-105 ${
                        isDark
                          ? "border-cyan-500/50 text-cyan-400 hover:bg-cyan-500/10"
                          : "border-blue-300 text-blue-600 hover:bg-blue-50"
                      }`}
                    >
                      <Edit2 className="w-4 h-4 mr-2" />
                      {t.edit}
                    </Button>
                    <Button
                      onClick={handleDeleteTarget}
                      variant="outline"
                      className={`flex-1 rounded-xl transition-all hover:scale-105 ${
                        isDark
                          ? "border-red-500/50 text-red-400 hover:bg-red-500/10"
                          : "border-red-300 text-red-600 hover:bg-red-50"
                      }`}
                    >
                      <Trash2 className="w-4 h-4 mr-2" />
                      {t.delete}
                    </Button>
                  </div>
                </>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Progress Display - conditionally rendered */}
        {target && (
          <Card
            className={`border-2 ${
              isDark
                ? "bg-[#1a1a2e]/80 border-cyan-500/20 backdrop-blur-sm"
                : "bg-white/80 border-blue-200 backdrop-blur-sm"
            } ${neonBlue}`}
          >
            <CardHeader>
              <CardTitle
                className={`flex items-center gap-2 ${
                  isDark ? "text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-500" : "text-gray-900"
                }`}
              >
                <TrendingUp className="w-5 h-5" />
                {t.progress}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid sm:grid-cols-2 gap-4">
                <div
                  className={`p-6 rounded-xl ${
                    isDark
                      ? "bg-gradient-to-br from-cyan-500/10 to-blue-500/5"
                      : "bg-gradient-to-br from-cyan-50 to-blue-50"
                  }`}
                >
                  <p className={`text-sm font-medium ${isDark ? "text-cyan-400" : "text-cyan-700"}`}>
                    {t.currentSavings}
                  </p>
                  <p
                    className={`text-3xl font-bold mt-2 ${
                      isDark
                        ? "text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-500"
                        : "text-cyan-700"
                    }`}
                  >
                    {formatRupiah(totalSavings)}
                  </p>
                </div>
                <div
                  className={`p-6 rounded-xl ${
                    isDark
                      ? "bg-gradient-to-br from-green-500/10 to-emerald-500/5"
                      : "bg-gradient-to-br from-green-50 to-emerald-50"
                  }`}
                >
                  <p className={`text-sm font-medium ${isDark ? "text-green-400" : "text-green-700"}`}>{t.target}</p>
                  <p
                    className={`text-3xl font-bold mt-2 ${
                      isDark
                        ? "text-transparent bg-clip-text bg-gradient-to-r from-green-400 to-emerald-500"
                        : "text-green-700"
                    }`}
                  >
                    {formatRupiah(target.total)}
                  </p>
                </div>
              </div>

              {/* Progress Bar */}
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className={isDark ? "text-gray-400" : "text-gray-600"}>{t.progress}</span>
                  <span className={`font-bold ${isDark ? "text-cyan-400" : "text-blue-600"}`}>
                    {progressPercentage.toFixed(1)}%
                  </span>
                </div>
                <div
                  className={`w-full h-6 rounded-full overflow-hidden ${isDark ? "bg-[#0a0e27]/50" : "bg-gray-200"}`}
                >
                  <div
                    className={`h-full transition-all duration-1000 ease-out ${
                      isDark
                        ? "bg-gradient-to-r from-cyan-500 via-blue-500 to-purple-500"
                        : "bg-gradient-to-r from-cyan-500 to-blue-500"
                    } ${neonBlue}`}
                    style={{ width: `${progressPercentage}%` }}
                  />
                </div>
              </div>

              {/* Circular Progress */}
              <div className="flex justify-center py-4">
                <div className="relative w-48 h-48">
                  <svg className="transform -rotate-90 w-48 h-48">
                    <circle
                      cx="96"
                      cy="96"
                      r="88"
                      stroke={isDark ? "#1a1a2e" : "#e5e7eb"}
                      strokeWidth="16"
                      fill="none"
                    />
                    <circle
                      cx="96"
                      cy="96"
                      r="88"
                      stroke="url(#progressGradient)"
                      strokeWidth="16"
                      fill="none"
                      strokeLinecap="round"
                      strokeDasharray={`${2 * Math.PI * 88}`}
                      strokeDashoffset={`${2 * Math.PI * 88 * (1 - progressPercentage / 100)}`}
                      className="transition-all duration-1000 ease-out"
                      style={{
                        filter: isDark ? "drop-shadow(0 0 8px rgba(0,212,255,0.6))" : "none",
                      }}
                    />
                    <defs>
                      <linearGradient id="progressGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                        <stop offset="0%" stopColor="#00d4ff" />
                        <stop offset="50%" stopColor="#3b82f6" />
                        <stop offset="100%" stopColor="#a855f7" />
                      </linearGradient>
                    </defs>
                  </svg>
                  <div className="absolute inset-0 flex flex-col items-center justify-center">
                    <span
                      className={`text-4xl font-bold ${
                        isDark
                          ? "text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-500"
                          : "text-gray-900"
                      }`}
                    >
                      {progressPercentage.toFixed(0)}%
                    </span>
                    {progressPercentage >= 100 && (
                      <span className="text-sm mt-2 text-green-400 font-semibold animate-pulse">
                        {t.congratulations}
                      </span>
                    )}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Transaction Records */}
        <Card
          className={`border-2 ${
            isDark
              ? "bg-[#1a1a2e]/80 border-cyan-500/20 backdrop-blur-sm"
              : "bg-white/80 border-blue-200 backdrop-blur-sm"
          }`}
        >
          <CardHeader>
            <CardTitle
              className={`flex items-center gap-2 ${
                isDark ? "text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-500" : "text-gray-900"
              }`}
            >
              <Wallet className="w-5 h-5" />
              {t.transactions}
            </CardTitle>
          </CardHeader>
          <CardContent>
            {records.length === 0 ? (
              <div className="text-center py-12">
                <PieChart className={`w-16 h-16 mx-auto mb-4 ${isDark ? "text-cyan-400/50" : "text-blue-300"}`} />
                <p className={`text-lg font-medium ${isDark ? "text-gray-400" : "text-gray-600"}`}>
                  {t.noTransactions}
                </p>
                <p className={`text-sm mt-2 ${isDark ? "text-gray-500" : "text-gray-500"}`}>{t.startAdding}</p>
              </div>
            ) : (
              <div className="space-y-3">
                {records.map((record) => (
                  <div
                    key={record.id}
                    className={`flex items-center justify-between p-4 rounded-xl transition-all hover:scale-[1.02] ${
                      isDark ? "bg-[#0a0e27]/50 hover:bg-[#0a0e27]/80" : "bg-gray-50 hover:bg-gray-100"
                    } ${
                      record.type === "income"
                        ? isDark
                          ? "border-l-4 border-green-400"
                          : "border-l-4 border-green-500"
                        : record.type === "expense"
                          ? isDark
                            ? "border-l-4 border-red-400"
                            : "border-l-4 border-red-500"
                          : isDark
                            ? "border-l-4 border-cyan-400"
                            : "border-l-4 border-cyan-500"
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <div
                        className={`p-2 rounded-lg ${
                          record.type === "income"
                            ? isDark
                              ? "bg-green-500/20"
                              : "bg-green-100"
                            : record.type === "expense"
                              ? isDark
                                ? "bg-red-500/20"
                                : "bg-red-100"
                              : isDark
                                ? "bg-cyan-500/20"
                                : "bg-cyan-100"
                        }`}
                      >
                        {record.type === "income" ? (
                          <TrendingUp className={`w-5 h-5 ${isDark ? "text-green-400" : "text-green-600"}`} />
                        ) : record.type === "expense" ? (
                          <Wallet className={`w-5 h-5 ${isDark ? "text-red-400" : "text-red-600"}`} />
                        ) : (
                          <PieChart className={`w-5 h-5 ${isDark ? "text-cyan-400" : "text-cyan-600"}`} />
                        )}
                      </div>
                      <div>
                        <p className={`font-semibold ${isDark ? "text-gray-200" : "text-gray-900"}`}>{record.month}</p>
                        <p
                          className={`text-sm ${
                            record.type === "income"
                              ? isDark
                                ? "text-green-400"
                                : "text-green-600"
                              : record.type === "expense"
                                ? isDark
                                  ? "text-red-400"
                                  : "text-red-600"
                                : isDark
                                  ? "text-cyan-400"
                                  : "text-cyan-600"
                          }`}
                        >
                          {record.type === "income" ? t.income : record.type === "expense" ? t.expense : t.saving}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      <p
                        className={`text-lg font-bold ${
                          record.type === "income"
                            ? isDark
                              ? "text-green-400"
                              : "text-green-600"
                            : record.type === "expense"
                              ? isDark
                                ? "text-red-400"
                                : "text-red-600"
                              : isDark
                                ? "text-cyan-400"
                                : "text-cyan-600"
                        }`}
                      >
                        {formatRupiah(record.amount)}
                      </p>
                      <div className="flex gap-1">
                        <Button
                          onClick={() => handleEditRecord(record)}
                          variant="outline"
                          size="icon"
                          className={`rounded-full transition-all hover:scale-110 w-8 h-8 ${
                            isDark
                              ? "border-cyan-500/50 text-cyan-400 hover:bg-cyan-500/10"
                              : "border-blue-300 text-blue-600 hover:bg-blue-50"
                          }`}
                        >
                          <Edit2 className="w-3 h-3" />
                        </Button>
                        <Button
                          onClick={() => handleDeleteRecord(record.id)}
                          variant="outline"
                          size="icon"
                          className={`rounded-full transition-all hover:scale-110 w-8 h-8 ${
                            isDark
                              ? "border-red-500/50 text-red-400 hover:bg-red-500/10"
                              : "border-red-300 text-red-600 hover:bg-red-50"
                          }`}
                        >
                          <Trash2 className="w-3 h-3" />
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </main>
    </div>
  )
}
